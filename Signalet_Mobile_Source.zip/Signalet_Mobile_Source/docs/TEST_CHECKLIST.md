# Acceptance test checklist

Run only after the native runners have been generated and the project compiles. Record real device/OS, build hash, inference time and any memory issue; do not mark unrun tests as pass.

## Model manager

- [ ] First use requires consent before downloading (~829 MB).
- [ ] Progress moves from 0–100%; cancel/interruption then retry behavior is observed and logged.
- [ ] Insufficient storage returns clear error without claiming ready.
- [ ] SHA-256 mismatch fails closed and does not allow analysis.
- [ ] Successful download performs a real runtime smoke test.
- [ ] Delete/re-download clears the installed runtime copy and restores ready state only after verification.
- [ ] Unsupported runtime / allocation / OOM errors are visible with retry guidance.

## Real local inference

- [ ] Physical Android arm64 device: model loads and a selected real chart screenshot gives a fresh model response.
- [ ] Physical iPhone with Xcode signing: same test. If not tested, iOS remains unverified.
- [ ] After model installation, enable airplane mode and analyse a screenshot successfully.
- [ ] Check process/network logs during inference; no external AI requests occur.
- [ ] JPEG, PNG and WebP inputs work through both gallery/file picker paths.
- [ ] Crop, rotate, change, retake and remove image controls work.
- [ ] Blurry, tiny, and non-chart images return WAIT / UNABLE TO READ in observed tests.
- [ ] No production sample responses, fake signal, or cached prior output appear.
- [ ] Record inference latency and peak memory on each target device.

## Validation and safety

- [ ] Invalid JSON is UNABLE_TO_READ.
- [ ] Unknown enum or invalid field types do not become a trade signal.
- [ ] BUY levels only pass if `SL < entry low <= entry high < TP`.
- [ ] SELL levels only pass if `TP < entry low <= entry high < SL`.
- [ ] Missing/unreadable prices cause WAIT and no shown entry/SL/TP.
- [ ] Symbol/timeframe mismatch causes WAIT.
- [ ] No lot sizing, MT5 credentials, trade API, or order-execution call is present.

## Local history and permissions

- [ ] History persists after app restart.
- [ ] Delete one entry deletes its image thumbnail.
- [ ] Clear all deletes all thumbnails and metadata.
- [ ] Turning thumbnail saving off deletes existing saved thumbnails.
- [ ] Verify app asks only for necessary photo/camera permissions; no location/contacts/microphone.


## Local automated tests

- `test/resumable_model_file_downloader_test.dart`: local HTTP server intentionally interrupts the first response, then verifies the next request resumes using `Range`, reproduces the entire byte-for-byte file, and rejects a wrong checksum. No Internet connection is required for this test.
- `test/app_controller_lock_test.dart`: download cannot start during inference and inference cannot start during model operations.
- `test/local_history_test.dart`: deleting records removes only app-owned saved screenshots; it must not delete a path outside `saved_scans`.

Run `flutter test --reporter expanded` on a Flutter-enabled host. These tests were authored but remain unexecuted until the Flutter SDK/dependencies are available.
