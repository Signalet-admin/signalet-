# App specification

## Product

SIGN ALET / Signalet is an offline-first Android and iOS app for cautious, user-initiated analysis of a single MT5 Forex chart screenshot. Its outputs are informational and manually reviewed; there is no MT5 link or order execution.

## Core user flow

1. User explicitly downloads the public local model from Settings/Scan (one-time setup, approximately 829 MB).
2. User chooses a JPG/JPEG/PNG/WebP image from Gallery or Files, optionally captures a new photo, crops or rotates it, then previews or removes it.
3. User selects the symbol and timeframe and enters any optional current price / account context.
4. App passes exactly one screenshot and an evidence-focused prompt to a new local LiteRT-LM chat.
5. App parses the model response as JSON and applies strict schema and price-order validation.
6. Results show BUY / SELL / WAIT / UNABLE TO READ, observations, unknowns, invalidation, limitations and only validated proposed levels.
7. Metadata is saved locally. Screenshot thumbnails are off by default and optional.

## Requirements

- Dark charcoal/near-black surfaces, white/grey text, lime accent.
- Scan / History / Settings navigation.
- Local vision model manager with explicit consent, progress, retry, checksum verification, runtime smoke test, delete/re-download, and errors.
- No inference request leaves the phone.
- No accounts, logins, broker credentials or trade execution.
- If inputs or outputs fail validation, never show an actionable BUY/SELL with price levels.

## Output schema

`status`: `BUY | SELL | WAIT | UNABLE_TO_READ`

`symbol`: string

`timeframe`: string

`observations`: array of strings

`structure`: `bullish | bearish | ranging | unclear`

`pullback`: `present | absent | unclear`

`setup_reason`: string

`entry_zone`: null or `{ "low": number, "high": number }`

`stop_loss`: null or number

`take_profit`: null or number

`invalidation`: string

`unreadable_items`: array of strings

`limitations`: array of strings

BUY ordering: `stop_loss < entry_zone.low <= entry_zone.high < take_profit`.

SELL ordering: `take_profit < entry_zone.low <= entry_zone.high < stop_loss`.

All price levels must be positive finite JSON numbers. Any mismatch, incomplete levels, or invalid ordering forces WAIT and removes the levels.
