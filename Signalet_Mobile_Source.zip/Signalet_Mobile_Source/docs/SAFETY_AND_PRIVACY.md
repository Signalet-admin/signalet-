# Safety and privacy

## Privacy commitments in application source

- No user account or sign-in.
- No MT5 credentials, broker credentials, API keys, analytics, telemetry or Firebase.
- No image upload for model inference. The local app passes bytes to the on-device LiteRT-LM runtime.
- A network connection is used only after explicit consent for the model download/update URL.
- Result history is stored locally. Thumbnail saving is off by default and user-controlled.
- Deleting a history row deletes its associated stored thumbnail; disabling thumbnail saving deletes all existing stored thumbnails.
- There is no MT5 integration or automatic order execution.

## Required user permissions

- Photo/file access is handled through Android/iOS system pickers; don't request broad storage permissions.
- Camera permission is only needed when the user taps Take Photo.
- Android `INTERNET` permission is required for the one-time model download. It is a platform-level permission; it does not mean inference needs the internet.
- No location, contacts, microphone, or notifications are required.

## Trading output safety

- Model output is untrusted, parsed with JSON parser and enum/type validation.
- BUY/SELL prices are shown only if all required levels are finite, positive and consistently ordered.
- Missing or inconsistent levels become WAIT with null levels.
- Symbol/timeframe mismatch becomes WAIT and drops levels.
- Current prices that cannot be read from the screenshot are never invented; current price is an optional manually-entered value and is not claimed to be live verified.
- No confidence or win-rate values are displayed.
- No lot size is calculated in v1, because contract/tick specifications are not supplied and verified.

## Remaining limits

A small vision-language model can still hallucinate plausible-looking output even when the image is poor or non-chart. Prompt constraints and validation reduce risk but do not guarantee semantic correctness. Acceptance tests for blurry and non-chart screenshots must be run on the selected physical devices. Use demo only and manually verify live price, spread, position size and stop/take-profit in MT5.
