# Build and acceptance status — 2026-10-18

## Current status

**Source project improved; native compilation and on-device inference remain unverified.** This is not yet a verified APK or signed IPA. A hosted GitHub Actions workflow has been added as the practical route to obtain real build artifacts without installing the toolchain locally. It has not yet been triggered, so no cloud build or device test is claimed.

## Work completed in this pass

- Added `.github/workflows/mobile-build.yml` with separate Ubuntu Android ARM64 APK and macOS iOS Simulator jobs. The workflow creates Flutter runner projects, resolves packages, formats Dart source, runs the static source/privacy guard, invokes analyzer and unit tests, and builds artifacts.
- Added `docs/CLOUD_BUILD.md` with exact upload/run/artifact retrieval steps.
- Fixed picked-image normalization so document-picker paths are copied into app-managed temporary storage; this avoids treating Android `content://` URIs as regular filesystem paths and makes crop/rotate/preview use consistent local files.
- Kept the selected original screenshot separately from the crop/rotation used for analysis, so optional history thumbnails save the original image.
- Fixed cancellation requested during model startup so the request is issued when the runtime makes cancellation available.
- Fixed the model smoke-test image: it is a valid 16×16 PNG and the setup path exercises actual image+text inference rather than text-only generation.
- Made LiteRT-LM runtime initialization share one in-flight Future to prevent Settings storage reads racing the app startup initialization.
- Replaced opaque installer-side model downloads with an explicit app-private HTTPS downloader that supports HTTP Range resume, exact byte counters, `Content-Range` validation, checksum verification before promotion, and safe handling when a host ignores Range or rejects a saved offset. The verified file is then registered with LiteRT-LM using its documented `fromFile` installation source.
- Added local-server unit tests for interrupted-transfer resume and rejection of files with a checksum mismatch. Added a history path-safety guard and tests for operation locking across tabs.
- Added cross-screen operation locking so model deletion/download cannot race a chart inference launched from another tab; progress now reports transferred bytes rather than an estimated byte count derived from the percentage.
- Added the runtime's local model storage accounting to Settings alongside saved screenshot thumbnail usage. Added a private verification marker so the app avoids streaming the full ~829 MB file hash and re-running the image smoke test before every ordinary scan; the marker is invalidated if the model's size/mtime no longer matches, triggering a fresh checksum and sample test.
- Fixed double-valued UI preference clamping and added tests for SELL price ordering, WAIT clearing levels, non-positive levels and timeframe mismatches.
- Added best-effort cleanup of app-managed temporary screenshot/crop/rotate files after replacement, removal or screen disposal.
- Made application startup idempotent and ensured the interface is released even if preference/history reads fail.
- Updated platform setup to set the iOS Runner target itself to iOS 15.0 in addition to the Podfile.

## Checks that actually ran in this environment

- `python3 tool/verify_source.py`: PASS for source structure, the model hash format, local image inference path, fail-closed output parsing, resumable download/checked activation, and workflow content.
- `python3 -m py_compile tool/configure_platforms.py tool/verify_source.py`: PASS.
- `bash -n tool/bootstrap_platforms.sh`: PASS.
- Downloader and app-operation-lock unit tests were added but could not be executed without the Dart/Flutter SDK.
- Updated ZIP archive validation: PASS after packaging (`unzip -t`), recorded in the delivered source bundle.

## Checks that did not run

- `flutter pub get`, `flutter analyze`, `flutter test`, Android APK build, iOS Simulator build and physical-device acceptance tests were **NOT RUN**.
- The environment has no Flutter/Dart executable, Android SDK/Gradle tooling, adb, Xcode or iOS simulator. The container cannot resolve `storage.googleapis.com`, and its HTTP downloader failed too, so the SDK and dependency packages cannot be installed into this session.
- No device/OS, model download result, measured inference time, memory usage, airplane-mode result or acceptance-test PASS is claimed.

## How to complete the build

Use the hosted workflow documented in `CLOUD_BUILD.md`. This remaining step requires pushing the source to a GitHub repository with the workflow included; a GitHub runner must actually execute before an APK can be provided honestly. Review logs and fix any real errors before treating the artifact as usable. Install the debug APK on a physical ARM64 Android device, download the 829 MB model, and verify image+text inference in airplane mode. The iOS Simulator build, if successful, is unsigned and does not prove physical iPhone performance or signing.
