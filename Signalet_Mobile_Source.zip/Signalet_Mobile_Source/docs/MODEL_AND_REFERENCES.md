# Model and references

## Selected first model

- Display name: LLaVA-OneVision-0.5B (LiteRT-LM bundle)
- File: `LLaVA-OneVision-0.5B.litertlm`
- Hosting: `https://huggingface.co/litert-community/LLaVA-OneVision-0.5B`
- Direct download: `https://huggingface.co/litert-community/LLaVA-OneVision-0.5B/resolve/main/LLaVA-OneVision-0.5B.litertlm`
- Published size: 829 MB
- Published license: Apache-2.0
- Published SHA-256: `7f7cd7ae3d2ae435a1f69651de02a9d51e916be60fdfef5cadc721725310971a`
- Image path: fixed 384×384 resolution; model card describes 729 SigLIP patches plus image newline token.
- Intended use: general single-image visual question-answering, not Forex-specific signal prediction.

The application pins the published SHA-256 and fails closed if the downloaded file changes. An intentional future model update must update the URL/revision, expected hash, license and tests together.

## Official/current references checked 2026-10-18

1. Google LiteRT-LM overview: https://developers.google.com/edge/litert-lm/overview — Kotlin stable, Swift early preview, Flutter integration via community package; supports mobile targets.
2. Flutter Edge AI (successor to flutter_gemma): https://pub.dev/packages/flutter_edge_ai — current package docs list `flutter_edge_ai` 2.4.0 and engine package `flutter_edge_ai_litertlm` 1.14.0; local model management API.
3. Flutter Edge AI multimodal guide: https://flutteredge.ai/docs/multimodal — documents `supportImage: true`, `Message.withImages`, and `createChat(supportImage: true)` for image input.
4. Flutter Edge AI model catalog: https://flutteredge.ai/docs/models — lists LLaVA-OneVision 0.5B as an image-capable `.litertlm` model on Android and iOS, using `ModelType.general`.
5. Model card: https://huggingface.co/litert-community/LLaVA-OneVision-0.5B — Apache-2.0, 829 MB, SHA-256 and image resolution; warns that the model should be used with one image per conversation.
6. Image picker: https://pub.dev/packages/image_picker — official Flutter plugin for Gallery/Photos and camera image selection.
7. Image cropper: https://pub.dev/packages/image_cropper — Flutter plugin for crop/rotation on supported mobile platforms.

## Dependency notices

- `flutter_edge_ai`, `flutter_edge_ai_litertlm`: see their current package license and included third-party notices before redistributing app bundles.
- LLaVA-OneVision model bundle: Apache-2.0; retain the model card attribution/license if distributing the weights or a derivative.
- `image_picker`: Apache-2.0 / BSD-3-Clause components.
- `image_cropper`: BSD-3-Clause.
- `path_provider`, `file_selector`, `shared_preferences`, `image`, `path`, and `crypto`: check package metadata for each resolved version at build time.

The dependencies are not vendored in this source package; Flutter resolves them from their package registries. Commit the generated `pubspec.lock` after the first successful `flutter pub get` to pin exact versions.
