# Build and signing instructions

## Option A: Hosted build without local Android SDK

Follow [`CLOUD_BUILD.md`](CLOUD_BUILD.md). The repository workflow will create runner scaffolding, run checks, and attempt an Android ARM64 debug APK plus an unsigned iOS Simulator build on hosted GitHub runners. The hosted workflow has not been run from this workspace; its results must be verified in the Actions logs. A simulator artifact is not a signed iPhone app.

## Option B: Local build prerequisites

- Current stable Flutter SDK and bundled Dart SDK.
- Android Studio + Android SDK, API 30 or higher installed, JDK supported by the installed Flutter/Gradle template.
- Android physical test handset: ARM64 (`arm64-v8a`) and ideally 8 GB RAM for multimodal inference. Smaller-memory devices may fail to load the model.
- For iOS: a Mac, current Xcode, command-line tools, CocoaPods where required, an Apple Developer signing team for physical-device/release installs.
- Internet connection only for dependency resolution and the user's explicitly approved one-time model download. After model installation, runtime inference should work in airplane mode.

## Generate native runner projects and apply settings

Run from the extracted `Signalet_Mobile_Source` folder:

```bash
flutter --version
flutter doctor -v
bash tool/bootstrap_platforms.sh
```

The bootstrap script generates standard Android/iOS runner scaffolding if absent, applies minimum platform settings, then runs `flutter pub get`. Review the generated diff rather than blindly overwriting source. If Flutter CLI changes generated Gradle syntax in a later version, apply the same effective settings manually and keep this document current.

Then run:

```bash
flutter analyze
flutter test
```

Fix all errors and investigate warnings before building. These commands have **not** been run in the authoring environment (see `BUILD_STATUS.md`).

## Android debug APK

```bash
flutter build apk --debug --target-platform android-arm64
```

Expected output after a successful build:

`build/app/outputs/flutter-apk/app-debug.apk`

Install via USB/debugging with an authorized Android phone connected:

```bash
flutter install --release
```

For debug testing, `flutter run` is also suitable. Install a debug APK directly from the output path if preferred.

## Android signed release APK

1. Create a keystore using Android Studio's signing wizard or `keytool`. Keep it backed up securely and do not commit it.
2. Configure signing in the generated `android/app/build.gradle` or `build.gradle.kts` using environment variables or a local untracked properties file. Never hard-code keystore passwords in source.
3. Set the release application ID, version, app label and icon.
4. Run the acceptance checklist in `TEST_CHECKLIST.md` on a physical ARM64 device.
5. Build:

```bash
flutter build apk --release --target-platform android-arm64
```

Expected output after a successful build:

`build/app/outputs/flutter-apk/app-release.apk`

A release build is not validated just because compilation succeeds. Complete offline inference, privacy, image-input and failure-mode tests first.

## iOS build (macOS + Xcode required)

1. Open `ios/Runner.xcworkspace` in Xcode after `flutter pub get` and CocoaPods setup.
2. Set the unique bundle identifier and select a valid Signing Team under Signing & Capabilities.
3. Confirm iOS Deployment Target is 15.0 or newer and `ios/Podfile` uses static framework linkage (`use_frameworks! :linkage => :static`).
4. Confirm `Runner.entitlements` includes the three model-memory keys documented by Flutter Edge AI for large models. Apple may require entitlements/profile approval depending on distribution. Do not assume entitlement use makes a model fit within a device's memory.
5. Select a physical iPhone or supported simulator and build/run. iOS simulator inference and memory behavior do not substitute for physical-device acceptance tests.
6. For an IPA, select a valid distribution signing workflow (Development, Ad Hoc, or App Store) and archive/export in Xcode. A signed IPA cannot be produced without the signing credentials/profile and macOS/Xcode.

## Model setup and offline check

1. Launch Signalet, open model setup, read the license/size notice, and explicitly consent to the ~829 MB bundle download.
2. Use reliable Wi-Fi and retain at least ~2 GB of free storage.
3. Wait for checksum verification and the runtime smoke test to complete. Do not mark the model ready if either step fails.
4. Once model status is Ready, enable airplane mode, select an image, and run analysis. Only after this passes should local/offline inference be considered verified.
5. The model host is currently Hugging Face. There is no cloud inference fallback. A changed upstream bundle hash intentionally fails verification; only update model URL/hash after reviewing the changed model card and license.

## Evidence to record before release

Record source commit/hash, Flutter/Dart and plugin versions, handset model and OS, model bundle SHA-256, downloaded byte size, elapsed download time, first-load and warm inference times, peak memory/OOM reports, actual airplane-mode result, test results, and iOS evidence where applicable. Never report a test as PASS unless the corresponding build/device test actually ran.
