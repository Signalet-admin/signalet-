# Architecture

## Layers

- `lib/screens/`: Flutter UI for Scan, History, Settings.
- `lib/models/signal_result.dart`: strict typed output model, JSON parser, enum validation and fail-closed BUY/SELL price ordering.
- `lib/services/analysis_service.dart`: constructs the prompt, creates a fresh image-enabled chat per screenshot, uses local `Message.withImages`, streams actual model tokens and validates JSON. No HTTP client or remote inference API is used here.
- `lib/services/model_manager.dart`: registers LiteRT-LM, coordinates explicit install/uninstall, app-private model storage, runtime initialization and an image+text smoke test.
- `lib/services/resumable_model_file_downloader.dart`: downloads only the publicly selected `.litertlm` file after consent; saves a `.part` file, resumes with HTTP Range, validates `Content-Range`, reports actual bytes, and promotes a download only after the published SHA-256 matches.
- `lib/services/local_history.dart`: app-private JSON history and optional image thumbnails with deletion of related files.
- `lib/services/preferences_store.dart`: user preferences in local shared preferences.
- `lib/services/app_controller.dart`: app-level state and local history/settings orchestration.

## Inference dependency

Current Flutter Edge AI package docs:

- `flutter_edge_ai` 2.4.x, now the successor to `flutter_gemma`.
- `flutter_edge_ai_litertlm` 1.14.x.
- Local model: `ModelType.general`, `ModelFileType.litertlm`.
- Image bridge: set `supportImage: true` at model load and chat creation, and pass the image as `Message.withImages(imageBytes: [Uint8List], text: ..., isUser: true)`.

The selected model is a single-image VQA model. A new chat is created for every scan to avoid accumulating image history.

## Network boundary

The only explicit app network workflow is the user-consented resumable model-file download from the pinned Hugging Face hosting URL. It uses HTTPS and HTTP Range for recovery after interrupted transfers. Inference, JSON validation, result display and history are local. Android's `INTERNET` permission is app-wide and cannot be restricted to a single hostname by the manifest; the application code itself uses no remote AI inference endpoint.

## Storage

- Model bundle and resumable `.part` file under app-private Application Support storage; LiteRT-LM registers the verified local file via its documented `fromFile` source. Deleting the model removes the registered model, installed bundle, and partial transfer.
- History JSON and optional thumbnails under application documents storage.
- Thumbnails disabled by default. Turning off deletes saved thumbnails and clears their paths from history.
- No cloud database or analytics.

## Runtime state

`notInstalled → downloading → checking → ready`; failures lead to `error`; delete transitions through `deleting` to `notInstalled`. Retry is permitted from `error`.

## Constraints

The app remains a human-in-the-loop demo assistant. It does not have market data, chart object access, a broker connection, or trading/execution integration. Model output is untrusted. The runtime cannot guarantee that the model visually reads prices accurately.
