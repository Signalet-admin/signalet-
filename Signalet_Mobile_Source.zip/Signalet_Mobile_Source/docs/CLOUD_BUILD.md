# Hosted build path (no local Flutter or Android SDK required)

The repository includes `.github/workflows/mobile-build.yml`. Once this folder is pushed to a GitHub repository, GitHub-hosted runners will generate the standard Flutter Android/iOS runner folders, resolve dependencies, format Dart, run static privacy checks, run `flutter analyze`, run the unit tests (including local HTTP range-resume and checksum tests), and attempt an Android ARM64 debug APK plus an unsigned iOS Simulator build. The workflow uploads build artifacts when they exist and keeps them for 14 days.

## Exact steps

1. Create a blank repository at https://github.com/new. Do not initialise it with another README/license if you want to avoid merge conflicts.
2. Download and extract `Signalet_Mobile_Source.zip` on any computer, or use GitHub's web upload UI to upload the extracted project contents. Upload the `.github` hidden folder too; without it, the workflow will not run.
3. Commit the files to `main` (or `master`). GitHub Actions starts automatically on push. It can also be started from **Actions → Signalet mobile builds → Run workflow**.
4. Open the latest workflow run. Read the Analyze and Tests logs first. A failed test/build is not a passing build.
5. When a job succeeds, open the run's **Artifacts** section and download `signalet-android-arm64-debug`. Install that debug APK only on a compatible ARM64 Android device for acceptance testing.
6. The `signalet-ios-simulator-unsigned` artifact, if produced, is for a simulator only. A physical iPhone install or App Store IPA still requires a Mac/Xcode signing workflow and the appropriate Apple signing identity/profile.

## Privacy note

The CI system builds source; it does not analyse chart images. Do not put API keys, MT5 credentials, private screenshots or signing secrets into this repository. Keep the repository private if desired, and check your GitHub plan's hosted-runner limits. No CI run has been executed from this authoring environment because it has no outbound package-network access or Flutter SDK.
