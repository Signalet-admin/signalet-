# Third-party notices

Signalet source is MIT-licensed. The model weights are not included in this source ZIP; the user downloads them explicitly from the official Hugging Face model repository.

## LLaVA-OneVision-0.5B LiteRT-LM
- Repository: https://huggingface.co/litert-community/LLaVA-OneVision-0.5B
- Model bundle: `LLaVA-OneVision-0.5B.litertlm`
- License listed by the model repository: Apache-2.0
- Local download URL is pinned in `lib/services/model_manager.dart`.
- Retain the model card and license attribution if distributing the model file.

## Flutter Edge AI
- `flutter_edge_ai`: https://pub.dev/packages/flutter_edge_ai
- `flutter_edge_ai_litertlm`: https://pub.dev/packages/flutter_edge_ai_litertlm
- The package project states MIT licensing. Check the exact resolved dependency notices when building a distributed binary.

## Flutter plugins
The project uses third-party Flutter packages declared in `pubspec.yaml`, including `image_picker`, `file_selector`, `image_cropper`, `image`, `path_provider`, `shared_preferences`, `crypto`, and `path`. Their dependency trees may have separate licenses. Generate a resolved `pubspec.lock` and inspect/package all notices required by the versions that are actually built; dependencies are not vendored into this source archive.
