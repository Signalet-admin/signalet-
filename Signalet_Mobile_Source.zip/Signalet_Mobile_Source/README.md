# Signalet — on-device chart analysis

Signalet is a Flutter Android/iOS source project for reviewing one MT5 Forex chart screenshot at a time with a vision-language model running on the phone. It does **not** connect to MT5, read live broker prices, submit orders, or guarantee trading outcomes.

> **Build status:** Source files and setup scripts are provided. This environment has no Flutter/Dart SDK, Android SDK/Gradle, Xcode, or iOS signing tools, so the app could not be compiled or run here. No APK/IPA is included and no device test is claimed. See `docs/BUILD_STATUS.md` for the exact blocker and acceptance-test status.

## What is implemented in source

- Dark charcoal UI with lime accent and Scan / History / Settings tabs.
- Gallery image picker, system file picker, camera capture, preview, crop, rotate, change and remove.
- On-device LiteRT-LM bridge through `flutter_edge_ai` + `flutter_edge_ai_litertlm`.
- One image per fresh inference chat, strict JSON parsing, and fail-closed level validation: a BUY/SELL with incomplete or incorrectly ordered levels is converted to WAIT with no levels.
- Model download with actual byte counters and HTTP Range resume, explicit consent, SHA-256 verification before model activation, an image+text runtime smoke test, retry/reuse of intact installs, deletion of checksum-invalid installs before re-download, and uninstall control. A private verification marker avoids re-hashing the ~829 MB model and re-running the image smoke test before every ordinary scan; size/mtime changes trigger a fresh integrity check.
- Best-effort generation cancellation when supported by the runtime; cancelled responses are not saved as scans.
- Local model-storage and saved-thumbnail storage readouts; optional screenshot thumbnail saving is off by default and associated image files are deleted with records.
- App-managed temporary copies of selected screenshots are cleaned up when changed, removed, rotated/cropped, or the screen is disposed.
- Unit test source for result validation, risk reference math, model-state transitions, history deletion/path safety, cross-screen operation locking, and a local HTTP test server that simulates interrupted/resumed model transfer and checksum failure.

These source features still require compilation and device acceptance testing before being called production-ready. The local cancellation action has not yet been runtime-verified. A hosted build workflow is included under `.github/workflows/mobile-build.yml`; see `docs/CLOUD_BUILD.md` for the exact steps to obtain build artifacts without installing a local SDK.

## Prerequisites

- Flutter stable and Dart compatible with `flutter_edge_ai` 2.4.x (use current stable Flutter; the current package docs describe Flutter Edge AI 2.4.0 and LiteRT-LM engine 1.14.0).
- Android: Android Studio/SDK, Android SDK Platform 30+, and an **arm64-v8a** device. LiteRT `.litertlm` support currently documents minSdk 30 and arm64-v8a on Android.
- iOS: a Mac with Xcode, CocoaPods (if needed by the generated project), and a valid signing Team for physical-device builds. Set iOS deployment target to 15.0. Simulator model execution may be memory-limited; validate on a real device.
- About 2 GB free storage for model setup and temporary files; 829 MB model download.

## Create native platform scaffolding

The repository includes a bootstrap script that generates runner scaffolding in a temporary Flutter project and copies only the missing native folders/metadata, avoiding overwrites of the supplied Dart source or `pubspec.yaml`. On a machine or hosted runner with Flutter installed, run:

```bash
cd Signalet_Mobile_Source
bash tool/bootstrap_platforms.sh
```

Then build and test using the commands below. The bootstrap script sets Android API/ABI and iOS deployment/memory/privacy settings, then runs `flutter pub get`.

- Android `minSdk = 30`; `abiFilters` restricted to `arm64-v8a`; add the network permission for explicit model download and optional camera permission for the Take Photo feature.
- iOS deployment target `15.0`; static framework linkage in `ios/Podfile`; add the documented model memory entitlements and photo/camera usage descriptions to Runner.

## Build and test

Run locally:

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

No local Flutter SDK? The project includes a GitHub Actions build workflow. Follow `docs/CLOUD_BUILD.md` to build an Android debug APK and an unsigned iOS Simulator app using hosted runners. The workflow now runs the local server download/resume test as part of `flutter test`.

Android debug APK:

```bash
flutter build apk --debug --target-platform android-arm64
```

The APK will be at `build/app/outputs/flutter-apk/app-debug.apk` if the build succeeds. See `docs/BUILD_AND_SIGNING.md` for a release-signed APK and Xcode iOS steps. Do not distribute a release until acceptance tests are run on the target devices.

## One-time model install

The app downloads the public model from Hugging Face only after the user confirms. The URL is:

`https://huggingface.co/litert-community/LLaVA-OneVision-0.5B/resolve/main/LLaVA-OneVision-0.5B.litertlm`

Published bundle size is approximately 829 MB. The published SHA-256 in the model card is pinned in source and checked after installation. If the upstream file changes, the integrity check fails closed rather than accepting a different model silently. Once installed, image analysis uses the local runtime and does not call a remote AI endpoint.

## Known limitations

- LLaVA-OneVision-0.5B is general image Q&A, not Forex-specific. It resizes images to 384×384, which is not ideal for tiny price labels. It may miss candles, levels or chart structure.
- LLM-generated JSON is untrusted. Validation reduces common failures but cannot guarantee the model will interpret a chart correctly. Treat BUY/SELL as unverified suggestions; prefer WAIT when price levels are unclear.
- The runtime and dependencies have not been compiled/tested in this authoring environment. The code contains a real resumable downloader with SHA-256 gating, but it still requires the hosted Flutter build/test workflow to prove it compiles and passes its local HTTP resume tests.
- iOS runtime support is documented by Flutter Edge AI for physical devices; no iOS device, simulator, or Xcode signing test was possible here.

## Privacy boundary

No accounts, telemetry, analytics, Firebase, serverless functions, broker credentials, MT5 login or remote order execution are present in app source. The runtime dependency uses network only for the explicit model setup/download path included here. Inference is implemented using local `Message.withImages` and `generateChatResponseAsync()` calls.
