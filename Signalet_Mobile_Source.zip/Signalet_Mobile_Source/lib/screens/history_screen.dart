import 'dart:io';

import 'package:flutter/material.dart';

import '../models/signal_result.dart';
import '../services/app_controller.dart';
import '../services/local_history.dart';
import '../theme.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key, required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final entries = controller.history;
    return ListView(padding: const EdgeInsets.fromLTRB(20, 20, 20, 28), children: [
      const Text('History', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      const SizedBox(height: 5),
      const Text('Private scan records saved on this device only.', style: TextStyle(color: SignaletTheme.muted, fontSize: 12)),
      const SizedBox(height: 18),
      if (entries.isNotEmpty) Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () async {
        final confirm = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
          title: const Text('Clear all history?'),
          content: const Text('All local scan records and associated saved thumbnails will be deleted from this device.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete all'))],
        ));
        if (confirm == true) await controller.clearHistory();
      }, icon: const Icon(Icons.delete_outline), label: const Text('Clear all history'))),
      if (entries.isEmpty)
        Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 42, horizontal: 20), child: Column(children: [const Icon(Icons.history, size: 38, color: SignaletTheme.muted), const SizedBox(height: 12), const Text('No scans yet', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), const SizedBox(height: 6), const Text('Your local scan results will appear here after the first analysis.', textAlign: TextAlign.center, style: TextStyle(color: SignaletTheme.muted, height: 1.45, fontSize: 12))]))),
      ...entries.map((entry) => _HistoryCard(entry: entry, onDelete: () async => controller.deleteHistoryEntry(entry.id))),
      const SizedBox(height: 12),
      const Text('History stores the result summary and optional image thumbnail. It does not contain MT5 login details, API credentials, or broker information.', style: TextStyle(color: SignaletTheme.muted, fontSize: 11, height: 1.5)),
    ]);
  }
}

class _HistoryCard extends StatelessWidget {
  const _HistoryCard({required this.entry, required this.onDelete});
  final HistoryEntry entry;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final color = switch (entry.status) { SignalStatus.buy => SignaletTheme.lime, SignalStatus.sell => const Color(0xFFFFB86B), _ => SignaletTheme.muted };
    final screenshot = entry.screenshotPath;
    return Padding(padding: const EdgeInsets.only(bottom: 10), child: Card(child: Padding(padding: const EdgeInsets.all(13), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (screenshot != null && File(screenshot).existsSync()) ...[
        ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(screenshot), width: 64, height: 64, fit: BoxFit.cover)),
        const SizedBox(width: 12),
      ],
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text('${entry.symbol} · ${entry.timeframe}', style: const TextStyle(fontWeight: FontWeight.w800))), Text(signalStatusLabel(entry.status), style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 11))]),
        const SizedBox(height: 4),
        Text('${entry.timestamp.toLocal()}'.split('.').first, style: const TextStyle(color: SignaletTheme.muted, fontSize: 10)),
        const SizedBox(height: 7),
        Text(entry.summary, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, height: 1.4)),
      ])),
      IconButton(tooltip: 'Delete scan', onPressed: onDelete, icon: const Icon(Icons.delete_outline, color: SignaletTheme.muted)),
    ]))));
  }
}
