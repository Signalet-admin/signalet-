import 'dart:async';

import 'package:flutter/material.dart';

import '../services/app_controller.dart';
import '../services/model_manager.dart';
import '../theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  int? _storageBytes;
  int? _modelStorageBytes;
  bool _busy = false;
  int _progress = 0;
  String? _operationError;
  bool _initialStorageLoaded = false;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onControllerChanged);
    unawaited(_loadStorage());
    _initialStorageLoaded = widget.controller.initialized;
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onControllerChanged);
    super.dispose();
  }

  void _onControllerChanged() {
    if (widget.controller.initialized && !_initialStorageLoaded) {
      _initialStorageLoaded = true;
      unawaited(_loadStorage());
    }
  }

  Future<void> _loadStorage() async {
    int? screenshotBytes;
    int? modelBytes;
    try {
      screenshotBytes = await widget.controller.savedScreenshotBytes();
    } catch (_) {
      screenshotBytes = null;
    }
    // Avoid racing runtime initialization. AppController's initialized flag
    // becomes true only after its startup model check and preferences load.
    if (widget.controller.initialized) {
      try {
        modelBytes = await widget.controller.modelManager.installedModelStorageBytes();
      } catch (_) {
        modelBytes = null;
      }
    }
    if (mounted) {
      setState(() {
        _storageBytes = screenshotBytes;
        _modelStorageBytes = modelBytes;
      });
    }
  }

  Future<void> _download() async {
    final accepted = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Download local AI model?'),
      content: const Text('Signalet will download about 829 MB from the published Hugging Face model host. The file remains in app-private storage. Prefer Wi-Fi and keep at least 2 GB free. No chart images are uploaded for inference. This is a one-time setup download; the model license is Apache-2.0.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Not now')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Download'))],
    ));
    if (accepted != true) return;
    setState(() { _busy = true; _progress = 0; _operationError = null; });
    try {
      await widget.controller.downloadModel((p) { if (mounted) setState(() => _progress = p); });
      await _loadStorage();
    } catch (e) {
      if (mounted) setState(() => _operationError = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deleteModel() async {
    final accepted = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Delete local model?'),
      content: const Text('This removes the downloaded AI model from app storage. You will need to download it again before analysing charts.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete model'))],
    ));
    if (accepted != true) return;
    setState(() { _busy = true; _operationError = null; });
    try {
      await widget.controller.deleteModel();
      await _loadStorage();
    } catch (e) {
      if (mounted) setState(() => _operationError = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final manager = widget.controller.modelManager;
    final ready = manager.isReady;
    return ListView(padding: const EdgeInsets.fromLTRB(20, 20, 20, 28), children: [
      const Text('Settings', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      const SizedBox(height: 5),
      const Text('Local model, storage and privacy controls.', style: TextStyle(color: SignaletTheme.muted, fontSize: 12)),
      const SizedBox(height: 18),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Icon(Icons.memory_rounded, color: SignaletTheme.lime, size: 25), const SizedBox(width: 10), const Expanded(child: Text('On-device AI model', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17))), Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: (ready ? SignaletTheme.lime : SignaletTheme.muted).withValues(alpha: .1), borderRadius: BorderRadius.circular(8)), child: Text(ready ? 'READY' : _label(manager.state), style: TextStyle(fontWeight: FontWeight.w800, fontSize: 10, color: ready ? SignaletTheme.lime : SignaletTheme.muted)))]),
        const SizedBox(height: 12),
        const Text('LLaVA-OneVision-0.5B · LiteRT-LM · ~829 MB', style: TextStyle(fontSize: 12)),
        const SizedBox(height: 8),
        Text('Model status: ${manager.error ?? (ready ? 'Downloaded, integrity-checked and sample-loaded.' : 'Not ready for local inference.')}', style: const TextStyle(color: SignaletTheme.muted, fontSize: 12, height: 1.45)),
        const SizedBox(height: 12),
        if (_busy) ...[LinearProgressIndicator(value: _progress > 0 ? _progress / 100 : null, color: SignaletTheme.lime), const SizedBox(height: 6), Text('$_progress% · ${_formatMegabytes(manager.downloadedBytes)} / ${_formatMegabytes(manager.totalDownloadBytes)} MB', style: const TextStyle(color: SignaletTheme.muted, fontSize: 11)), const SizedBox(height: 8)],
        if (_operationError != null) ...[Text(_operationError!, style: const TextStyle(color: SignaletTheme.warning, fontSize: 12)), const SizedBox(height: 8)],
        if (!ready) FilledButton.icon(onPressed: (_busy || !widget.controller.initialized || widget.controller.modelOperationInProgress || widget.controller.analysisInProgress) ? null : _download, icon: const Icon(Icons.download_rounded), label: Text(_busy ? 'Preparing…' : 'Download / retry model')),
        if (ready) OutlinedButton.icon(onPressed: (_busy || !widget.controller.initialized || widget.controller.modelOperationInProgress || widget.controller.analysisInProgress) ? null : _deleteModel, icon: const Icon(Icons.delete_outline), label: const Text('Delete local model')),
        const SizedBox(height: 10),
        const Text('Model license: Apache-2.0. The model is a general-purpose image-Q&A model, not a Forex-specialist model. It may misread tiny price labels and may not run on every device.', style: TextStyle(color: SignaletTheme.muted, fontSize: 11, height: 1.5)),
      ]))),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Risk preference', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        const SizedBox(height: 6),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Default maximum risk per trade', style: TextStyle(color: SignaletTheme.muted, fontSize: 12)), Text('${widget.controller.defaultRiskPercent.toStringAsFixed(2)}%', style: const TextStyle(color: SignaletTheme.lime, fontWeight: FontWeight.w800))]),
        Slider(min: 0.05, max: 1.0, divisions: 19, value: widget.controller.defaultRiskPercent.clamp(.05, 1.0).toDouble(), activeColor: SignaletTheme.lime, onChanged: (_busy || widget.controller.modelOperationInProgress || widget.controller.analysisInProgress) ? null : (value) => widget.controller.setDefaultRisk(value)),
        const Text('The number is for reference only in this version. Signalet does not calculate lot size or send orders.', style: TextStyle(color: SignaletTheme.muted, fontSize: 11, height: 1.4)),
      ]))),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Privacy', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        const SizedBox(height: 7),
        SwitchListTile(contentPadding: EdgeInsets.zero, activeColor: SignaletTheme.lime, title: const Text('Save screenshot thumbnails', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)), subtitle: const Text('Off by default. If disabled, history keeps only text summaries.', style: TextStyle(fontSize: 11, color: SignaletTheme.muted)), value: widget.controller.saveScreenshotThumbnails, onChanged: (_busy || widget.controller.modelOperationInProgress || widget.controller.analysisInProgress) ? null : (v) async { await widget.controller.setSaveScreenshotThumbnails(v); await _loadStorage(); }),
        const Divider(height: 20),
        _infoRow('Installed model storage', _modelStorageBytes == null ? 'Checking…' : _formatBytes(_modelStorageBytes!)),
        _infoRow('Saved thumbnail storage', _storageBytes == null ? 'Checking…' : _formatBytes(_storageBytes!)),
        _infoRow('Network use', 'Model download/update only'),
        _infoRow('Inference', 'On-device; no AI API'),
        _infoRow('Local history', 'App-private storage'),
        _infoRow('MT5 integration', 'None; manual entries only'),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: (_busy || widget.controller.modelOperationInProgress || widget.controller.analysisInProgress) ? null : () async { await widget.controller.setSaveScreenshotThumbnails(false); await _loadStorage(); }, icon: const Icon(Icons.delete_sweep_outlined), label: const Text('Delete all saved thumbnails')),
      ]))),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Important', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        const SizedBox(height: 7),
        const Text('This app provides unverified visual analysis, not financial advice. Always verify chart, live price, spread, contract specifications, stop-loss, take-profit and volume in MT5. Demo testing only. No profit guarantee. No automatic order execution. Screenshots and results remain on this device unless you manually share copied text.', style: TextStyle(color: SignaletTheme.muted, height: 1.55, fontSize: 12)),
      ]))),
      const SizedBox(height: 14),
      const Text('Signalet 1.0.0 · Android arm64 / min SDK 30 · iOS target 15.0 (Xcode required)', textAlign: TextAlign.center, style: TextStyle(color: SignaletTheme.muted, fontSize: 10)),
    ]);
  }

  String _label(ModelState state) => switch (state) {
        ModelState.notInstalled => 'NOT INSTALLED',
        ModelState.downloading => 'DOWNLOADING',
        ModelState.checking => 'CHECKING',
        ModelState.ready => 'READY',
        ModelState.deleting => 'DELETING',
        ModelState.error => 'ERROR',
      };
  Widget _infoRow(String label, String value) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(children: [Expanded(child: Text(label, style: const TextStyle(color: SignaletTheme.muted, fontSize: 12)),), const SizedBox(width: 12), Flexible(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontSize: 12)))]));
  String _formatMegabytes(int bytes) => (bytes / 1000000).toStringAsFixed(1);

  String _formatBytes(int bytes) => bytes < 1024 * 1024 ? '$bytes B' : '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
}
