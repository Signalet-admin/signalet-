import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_selector/file_selector.dart' as fs;
import 'package:image/image.dart' as img;
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import '../models/signal_result.dart';
import '../services/app_controller.dart';
import '../services/model_manager.dart';
import '../theme.dart';

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key, required this.controller, required this.onGoSettings});
  final AppController controller;
  final VoidCallback onGoSettings;

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  static const _timeframes = ['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1', 'W1'];
  final _picker = ImagePicker();
  final _symbol = TextEditingController(text: 'EURUSD');
  final _currentPrice = TextEditingController();
  final _balance = TextEditingController();
  String _timeframe = 'M15';
  String _currency = 'USD';
  String _strategy = 'Trend + market structure and pullback';
  double _riskPercent = 0.25;
  String? _imagePath;
  List<int>? _imageBytes;
  List<int>? _originalImageBytes;
  bool _busy = false;
  bool _analysisRunning = false;
  bool _cancelRequested = false;
  Future<void> Function()? _cancelAnalysis;
  int _downloadProgress = 0;
  String _stage = '';
  String? _error;
  SignalResult? _result;
  DateTime? _lastInferenceAt;

  @override
  void initState() {
    super.initState();
    _riskPercent = widget.controller.defaultRiskPercent.clamp(0.05, 1.0).toDouble();
    widget.controller.addListener(_syncRiskDefault);
  }

  void _syncRiskDefault() {
    if (!mounted || _busy) return;
    final next = widget.controller.defaultRiskPercent.clamp(0.05, 1.0).toDouble();
    if (next != _riskPercent) setState(() => _riskPercent = next);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_syncRiskDefault);
    _symbol.dispose();
    _currentPrice.dispose();
    _balance.dispose();
    unawaited(_deletePreviewFile(_imagePath));
    super.dispose();
  }

  Future<void> _pick(ImageSource source) async {
    try {
      final file = await _picker.pickImage(source: source, requestFullMetadata: false);
      if (file == null || !mounted) return;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) throw StateError('The selected image is empty.');
      final localPath = await _writePreviewCopy(bytes, file.name);
      if (!mounted) {
        unawaited(_deletePreviewFile(localPath));
        return;
      }
      final previousPath = _imagePath;
      setState(() {
        _imagePath = localPath;
        _imageBytes = bytes;
        _originalImageBytes = List<int>.from(bytes);
        _result = null;
        _error = null;
      });
      if (previousPath != localPath) unawaited(_deletePreviewFile(previousPath));
    } catch (e) {
      if (mounted) setState(() => _error = 'Could not open that image: $e');
    }
  }

  Future<void> _browseFiles() async {
    try {
      const typeGroup = fs.XTypeGroup(label: 'Chart images', extensions: ['jpg', 'jpeg', 'png', 'webp']);
      final file = await fs.openFile(acceptedTypeGroups: const [typeGroup]);
      if (file == null || !mounted) return;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) throw StateError('The selected file is empty.');
      final localPath = await _writePreviewCopy(bytes, file.name);
      if (!mounted) {
        unawaited(_deletePreviewFile(localPath));
        return;
      }
      final previousPath = _imagePath;
      setState(() {
        _imagePath = localPath;
        _imageBytes = bytes;
        _originalImageBytes = List<int>.from(bytes);
        _result = null;
        _error = null;
      });
      if (previousPath != localPath) unawaited(_deletePreviewFile(previousPath));
    } catch (e) {
      if (mounted) setState(() => _error = 'Could not open the selected file: $e');
    }
  }

  /// Copies picker/document-provider content into app-managed temporary storage.
  /// Some Android providers return content:// URIs which cannot be passed to
  /// File() or image_cropper directly. A local copy makes preview/crop/rotate
  /// consistent across Android and iOS without retaining the user's original.
  Future<String> _writePreviewCopy(List<int> bytes, String originalName) async {
    final dot = originalName.lastIndexOf('.');
    final candidate = dot >= 0 ? originalName.substring(dot).toLowerCase() : '.png';
    final extension = const {'.jpg', '.jpeg', '.png', '.webp'}.contains(candidate)
        ? candidate
        : '.png';
    final temp = await getTemporaryDirectory();
    final path = '${temp.path}/signalet_image_${DateTime.now().microsecondsSinceEpoch}$extension';
    await File(path).writeAsBytes(bytes, flush: true);
    return path;
  }

  Future<void> _deletePreviewFile(String? path) async {
    if (path == null || path.isEmpty) return;
    try {
      // _imagePath is always an app-managed temporary copy or a cropper
      // temporary output, never the original picked Gallery/Files item.
      final file = File(path);
      if (await file.exists()) await file.delete();
    } catch (_) {
      // Temporary cache cleanup is best-effort; never interrupt a scan.
    }
  }

  Future<void> _crop() async {
    final source = _imagePath;
    if (source == null) return;
    try {
      final cropped = await ImageCropper().cropImage(
        sourcePath: source,
        compressFormat: ImageCompressFormat.png,
        uiSettings: [
          AndroidUiSettings(
            toolbarTitle: 'Crop chart region',
            toolbarColor: SignaletTheme.background,
            toolbarWidgetColor: Colors.white,
            activeControlsWidgetColor: SignaletTheme.lime,
            backgroundColor: SignaletTheme.background,
            initAspectRatio: CropAspectRatioPreset.original,
            lockAspectRatio: false,
          ),
          IOSUiSettings(title: 'Crop chart region', doneButtonTitle: 'Use crop', cancelButtonTitle: 'Cancel'),
        ],
      );
      if (cropped == null || !mounted) return;
      final bytes = await File(cropped.path).readAsBytes();
      final previousPath = _imagePath;
      setState(() {
        _imagePath = cropped.path;
        _imageBytes = bytes;
        _result = null;
        _error = null;
      });
      if (previousPath != cropped.path) unawaited(_deletePreviewFile(previousPath));
    } catch (e) {
      if (mounted) setState(() => _error = 'Cropping failed: $e');
    }
  }

  Future<void> _rotate() async {
    final bytes = _imageBytes;
    if (bytes == null) return;
    try {
      final decoded = img.decodeImage(Uint8List.fromList(bytes));
      if (decoded == null) throw const FormatException('Unsupported or corrupted image.');
      final rotated = img.copyRotate(decoded, angle: 90);
      final pngBytes = img.encodePng(rotated);
      final temp = await getTemporaryDirectory();
      final file = File('${temp.path}/signalet_rotated_${DateTime.now().microsecondsSinceEpoch}.png');
      await file.writeAsBytes(pngBytes, flush: true);
      if (!mounted) {
        unawaited(_deletePreviewFile(file.path));
        return;
      }
      final previousPath = _imagePath;
      setState(() {
        _imagePath = file.path;
        _imageBytes = pngBytes;
        _result = null;
        _error = null;
      });
      if (previousPath != file.path) unawaited(_deletePreviewFile(previousPath));
    } catch (e) {
      if (mounted) setState(() => _error = 'Could not rotate image: $e');
    }
  }

  void _removeImage() {
    final previousPath = _imagePath;
    setState(() {
      _imagePath = null;
      _imageBytes = null;
      _originalImageBytes = null;
      _result = null;
      _error = null;
    });
    unawaited(_deletePreviewFile(previousPath));
  }

  Future<void> _analyze() async {
    final bytes = _imageBytes;
    final path = _imagePath;
    if (bytes == null || path == null || !widget.controller.modelManager.isReady) return;
    final symbol = _symbol.text.trim().toUpperCase();
    if (!RegExp(r'^[A-Z0-9._-]{3,16}$').hasMatch(symbol)) {
      setState(() => _error = 'Enter a valid symbol using 3–16 letters or numbers, for example EURUSD or XAUUSD.');
      return;
    }
    if (_balance.text.trim().isNotEmpty) {
      final balance = double.tryParse(_balance.text.trim());
      if (balance == null || !balance.isFinite || balance <= 0) {
        setState(() => _error = 'Account balance must be a positive number or left blank.');
        return;
      }
    }
    if (_currentPrice.text.trim().isNotEmpty) {
      final price = double.tryParse(_currentPrice.text.trim());
      if (price == null || !price.isFinite || price <= 0) {
        setState(() => _error = 'Current price must be a positive finite number or left blank.');
        return;
      }
    }
    try {
      widget.controller.beginAnalysis();
    } catch (e) {
      setState(() => _error = e.toString());
      return;
    }
    setState(() {
      _busy = true;
      _analysisRunning = true;
      _cancelRequested = false;
      _cancelAnalysis = null;
      _result = null;
      _error = null;
      _stage = 'Preparing local inference';
    });
    final started = DateTime.now();
    try {
      final result = await widget.controller.analysis.analyze(
        imageBytes: bytes,
        symbol: symbol,
        timeframe: _timeframe,
        currentPrice: _currentPrice.text,
        accountBalance: _balance.text,
        accountCurrency: _currency,
        riskPercent: _riskPercent,
        strategy: _strategy,
        onStage: (stage) {
          if (mounted) setState(() => _stage = stage);
        },
        onCancelReady: (cancel) {
          if (mounted) setState(() => _cancelAnalysis = cancel);
          // If the user tapped Cancel while the model was still loading, run
          // cancellation as soon as the runtime exposes its cancellation hook.
          if (_cancelRequested && cancel != null) unawaited(_issueCancel(cancel));
        },
      );
      if (_cancelRequested) {
        if (mounted) setState(() => _error = 'Analysis cancelled. No signal was produced or saved.');
        return;
      }
      await widget.controller.recordResult(
        result: result,
        imageBytes: _originalImageBytes ?? bytes,
      );
      if (!mounted) return;
      setState(() {
        _result = result;
        _lastInferenceAt = DateTime.now();
      });
    } catch (e) {
      if (mounted) setState(() => _error = 'Local analysis failed: $e\nNo cloud fallback was used. Check the local model and available memory, then retry.');
    } finally {
      widget.controller.endAnalysis();
      if (mounted) setState(() { _busy = false; _analysisRunning = false; _cancelAnalysis = null; });
    }
    // Keep a timing hook for future device-specific diagnostics; no unverified value is shown.
    final _elapsed = DateTime.now().difference(started);
    assert(_elapsed.inMilliseconds >= 0);
  }

  Future<void> _issueCancel(Future<void> Function() cancel) async {
    try {
      await cancel();
    } catch (e) {
      if (mounted) setState(() => _error = 'Cancellation failed: $e');
    }
  }

  Future<void> _cancelCurrentAnalysis() async {
    if (!_analysisRunning || _cancelRequested) return;
    setState(() {
      _cancelRequested = true;
      _stage = 'Cancelling local analysis…';
    });
    final cancel = _cancelAnalysis;
    if (cancel == null) {
      setState(() => _error = 'Cancellation is not yet available while the local model is starting. Please wait for startup to finish.');
      return;
    }
    await _issueCancel(cancel);
  }

  Future<void> _downloadModel() async {
    final accepted = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Download local AI model?'),
      content: const Text('This downloads about 829 MB from Hugging Face and stores the model in app-private storage. Keep at least 2 GB free and prefer Wi-Fi. Chart images are not uploaded for inference. The download is required once before offline analysis.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Not now')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Download'))],
    ));
    if (accepted != true || !mounted) return;
    setState(() {
      _busy = true;
      _downloadProgress = 0;
      _error = null;
    });
    try {
      await widget.controller.downloadModel((p) {
        if (mounted) setState(() => _downloadProgress = p);
      });
    } catch (e) {
      if (mounted) setState(() => _error = 'Model download/setup failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _formatMegabytes(int bytes) => (bytes / 1000000).toStringAsFixed(1);

  @override
  Widget build(BuildContext context) {
    final modelState = widget.controller.modelManager.state;
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      children: [
        Row(children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: SignaletTheme.lime.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(14)),
            child: const Icon(Icons.candlestick_chart_rounded, color: SignaletTheme.lime),
          ),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('SIGNALET', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: 2)),
            SizedBox(height: 2),
            Text('On-device chart review', style: TextStyle(color: SignaletTheme.muted, fontSize: 12)),
          ])),
          _ModelBadge(ready: widget.controller.modelManager.isReady),
        ]),
        const SizedBox(height: 22),
        _SectionTitle(title: 'Chart screenshot', subtitle: 'Images are analysed locally after the model is installed.'),
        const SizedBox(height: 12),
        Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            if (_imagePath == null) ...[
              Container(
                height: 170,
                decoration: BoxDecoration(color: SignaletTheme.surfaceAlt, borderRadius: BorderRadius.circular(14), border: Border.all(color: SignaletTheme.border)),
                child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.add_photo_alternate_outlined, size: 36, color: SignaletTheme.muted),
                  SizedBox(height: 10),
                  Text('Choose an MT5 chart screenshot', style: TextStyle(color: SignaletTheme.muted)),
                  SizedBox(height: 4),
                  Text('JPG · PNG · WebP', style: TextStyle(color: SignaletTheme.muted, fontSize: 12)),
                ]),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(onPressed: _busy ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library_outlined), label: const Text('Upload Screenshot')),
              const SizedBox(height: 8),
              OutlinedButton.icon(onPressed: _busy ? null : _browseFiles, icon: const Icon(Icons.folder_open_outlined), label: const Text('Browse Files')),
              const SizedBox(height: 8),
              OutlinedButton.icon(onPressed: _busy ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt_outlined), label: const Text('Take Photo')),
            ] else ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  constraints: const BoxConstraints(maxHeight: 300),
                  color: SignaletTheme.surfaceAlt,
                  child: Image.file(File(_imagePath!), fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Padding(padding: EdgeInsets.all(22), child: Text('Image preview is unavailable. Try selecting it again.'))),
                ),
              ),
              const SizedBox(height: 10),
              Text(_imagePath!.split(Platform.pathSeparator).last, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: SignaletTheme.muted, fontSize: 12)),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                OutlinedButton.icon(onPressed: _busy ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.sync), label: const Text('Change')),
                OutlinedButton.icon(onPressed: _busy ? null : _browseFiles, icon: const Icon(Icons.folder_open_outlined), label: const Text('Browse Files')),
                OutlinedButton.icon(onPressed: _busy ? null : _crop, icon: const Icon(Icons.crop), label: const Text('Crop')),
                OutlinedButton.icon(onPressed: _busy ? null : _rotate, icon: const Icon(Icons.rotate_right), label: const Text('Rotate')),
                OutlinedButton.icon(onPressed: _busy ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt_outlined), label: const Text('Retake')),
                OutlinedButton.icon(onPressed: _busy ? null : _removeImage, style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFFF9B9B)), icon: const Icon(Icons.close), label: const Text('Remove')),
              ]),
            ],
          ]),
        )),
        const SizedBox(height: 22),
        _SectionTitle(title: 'Analysis inputs', subtitle: 'These are user-entered values. Signalet is not connected to MT5.'),
        const SizedBox(height: 12),
        Card(child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(children: [
            Row(children: [
              Expanded(child: TextField(controller: _symbol, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Symbol'))),
              const SizedBox(width: 12),
              Expanded(child: DropdownButtonFormField<String>(value: _timeframe, decoration: const InputDecoration(labelText: 'Timeframe'), items: _timeframes.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: _busy ? null : (v) => setState(() => _timeframe = v ?? 'M15'))),
            ]),
            const SizedBox(height: 14),
            TextField(controller: _currentPrice, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Current price (optional)', hintText: 'Enter only if you can verify it in MT5')),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: TextField(controller: _balance, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Account balance (optional)', hintText: 'Enter manually'))),
              const SizedBox(width: 12),
              Expanded(child: DropdownButtonFormField<String>(value: _currency, decoration: const InputDecoration(labelText: 'Currency'), items: const ['USD', 'ZAR', 'EUR', 'GBP', 'Other'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: _busy ? null : (v) => setState(() => _currency = v ?? 'USD'))),
            ]),
            const SizedBox(height: 18),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Max risk per trade'), Text('${_riskPercent.toStringAsFixed(2)}%', style: const TextStyle(color: SignaletTheme.lime, fontWeight: FontWeight.bold))]),
            Slider(min: 0.05, max: 1.0, divisions: 19, value: _riskPercent, label: '${_riskPercent.toStringAsFixed(2)}%', onChanged: _busy ? null : (v) => setState(() => _riskPercent = v), onChangeEnd: (v) => widget.controller.setDefaultRisk(v), activeColor: SignaletTheme.lime),
            const SizedBox(height: 4),
            DropdownButtonFormField<String>(value: _strategy, isExpanded: true, decoration: const InputDecoration(labelText: 'Strategy preference'), items: const [
              DropdownMenuItem(value: 'Trend + market structure and pullback', child: Text('Trend + market structure and pullback')),
              DropdownMenuItem(value: 'Support and resistance', child: Text('Support and resistance')),
              DropdownMenuItem(value: 'Range / breakout review', child: Text('Range / breakout review')),
            ], onChanged: _busy ? null : (v) => setState(() => _strategy = v ?? 'Trend + market structure and pullback')),
          ]),
        )),
        const SizedBox(height: 16),
        if (!widget.controller.modelManager.isReady) _ModelSetupCard(
          state: modelState,
          progress: _downloadProgress,
          busy: _busy || widget.controller.modelOperationInProgress || widget.controller.analysisInProgress,
          onDownload: _downloadModel,
          onGoSettings: widget.onGoSettings,
          error: widget.controller.modelManager.error,
          enabled: widget.controller.initialized &&
              !widget.controller.modelOperationInProgress &&
              !widget.controller.analysisInProgress,
        ),
        if (_busy && _imagePath != null) ...[
          const SizedBox(height: 14),
          Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [Row(children: [const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: SignaletTheme.lime)), const SizedBox(width: 12), Expanded(child: Text(_stage.isEmpty ? 'Working locally…' : _stage, style: const TextStyle(color: SignaletTheme.muted)))]), if (_analysisRunning) ...[const SizedBox(height: 10), Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: _cancelRequested ? null : _cancelCurrentAnalysis, icon: const Icon(Icons.stop_circle_outlined), label: const Text('Cancel analysis')))] ]))),
        ],
        if (_error != null) ...[
          const SizedBox(height: 12),
          _MessageCard(text: _error!, isError: true),
        ],
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: (_imageBytes != null && widget.controller.modelManager.isReady && !_busy) ? _analyze : null,
          icon: const Icon(Icons.auto_awesome_outlined),
          label: Text(_busy ? 'Please wait…' : 'Analyze chart locally'),
        ),
        const SizedBox(height: 12),
        const Text('Local model only after setup. Chart screenshots are not uploaded for AI inference. Model output may be wrong. Verify live price, spread, SL/TP and volume in MT5. Demo testing only; no profit guarantee. Signalet never executes trades.', style: TextStyle(color: SignaletTheme.muted, fontSize: 12, height: 1.5)),
        if (_result != null) ...[
          const SizedBox(height: 24),
          _ResultCard(result: _result!),
          if (_lastInferenceAt != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text('Generated locally at ${TimeOfDay.fromDateTime(_lastInferenceAt!).format(context)}', style: const TextStyle(color: SignaletTheme.muted, fontSize: 11))),
        ],
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.subtitle});
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: SignaletTheme.muted, fontSize: 12, height: 1.4))]);
}

class _ModelBadge extends StatelessWidget {
  const _ModelBadge({required this.ready});
  final bool ready;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: (ready ? SignaletTheme.lime : SignaletTheme.muted).withValues(alpha: 0.10), borderRadius: BorderRadius.circular(999), border: Border.all(color: (ready ? SignaletTheme.lime : SignaletTheme.muted).withValues(alpha: 0.30))), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(ready ? Icons.check_circle : Icons.memory, size: 13, color: ready ? SignaletTheme.lime : SignaletTheme.muted), const SizedBox(width: 5), Text(ready ? 'LOCAL AI READY' : 'MODEL NOT READY', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: ready ? SignaletTheme.lime : SignaletTheme.muted))]));
}

class _ModelSetupCard extends StatelessWidget {
  const _ModelSetupCard({required this.state, required this.progress, required this.busy, required this.onDownload, required this.onGoSettings, required this.enabled, this.error});
  final ModelState state;
  final int progress;
  final bool busy;
  final bool enabled;
  final VoidCallback onDownload;
  final VoidCallback onGoSettings;
  final String? error;
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.memory, color: SignaletTheme.lime), SizedBox(width: 8), Text('Local AI model required', style: TextStyle(fontWeight: FontWeight.w800))]),
        const SizedBox(height: 8),
        const Text('Download LLaVA-OneVision-0.5B once (about 829 MB). Keep at least 2 GB free. After setup, analysis runs on this phone without AI API credits. Wi-Fi recommended.', style: TextStyle(color: SignaletTheme.muted, height: 1.5, fontSize: 12)),
        if (busy || state == ModelState.downloading) ...[
          const SizedBox(height: 14), LinearProgressIndicator(value: progress > 0 ? progress / 100 : null, color: SignaletTheme.lime), const SizedBox(height: 6), Text('$progress% · ${_formatMegabytes(widget.controller.modelManager.downloadedBytes)} / ${_formatMegabytes(widget.controller.modelManager.totalDownloadBytes)} MB', style: const TextStyle(color: SignaletTheme.muted, fontSize: 12)),
        ],
        if (error != null) ...[const SizedBox(height: 10), Text('Model issue: $error', style: const TextStyle(color: SignaletTheme.warning, fontSize: 12, height: 1.4))],
        const SizedBox(height: 14),
        FilledButton.icon(onPressed: (busy || !enabled) ? null : onDownload, icon: const Icon(Icons.download_rounded), label: Text(!enabled ? 'Checking app startup…' : state == ModelState.error ? 'Retry model setup' : 'Download and prepare model')),
        TextButton(onPressed: onGoSettings, child: const Text('Model settings')),
      ])));
}

class _MessageCard extends StatelessWidget {
  const _MessageCard({required this.text, required this.isError});
  final String text;
  final bool isError;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: isError ? const Color(0xFF29191A) : SignaletTheme.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: isError ? const Color(0xFF633336) : SignaletTheme.border)), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(isError ? Icons.error_outline : Icons.info_outline, color: isError ? SignaletTheme.warning : SignaletTheme.lime), const SizedBox(width: 10), Expanded(child: Text(text, style: TextStyle(color: isError ? SignaletTheme.warning : SignaletTheme.muted, height: 1.4, fontSize: 12))) ]));
}

class _ResultCard extends StatelessWidget {
  const _ResultCard({required this.result});
  final SignalResult result;
  @override
  Widget build(BuildContext context) {
    final color = switch (result.status) { SignalStatus.buy => SignaletTheme.lime, SignalStatus.sell => const Color(0xFFFFB86B), _ => const Color(0xFFCDD1D2) };
    return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text('Analysis result', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))), Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withValues(alpha: 0.45))), child: Text(signalStatusLabel(result.status), style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12))) ]),
      const SizedBox(height: 14),
      _resultRow('Symbol / timeframe', '${result.symbol} · ${result.timeframe}'),
      _resultRow('Structure', result.structure.name),
      _resultRow('Pullback', result.pullback.name),
      const SizedBox(height: 8),
      Text(result.setupReason, style: const TextStyle(height: 1.5)),
      if (result.validationNote != null) ...[const SizedBox(height: 10), Text(result.validationNote!, style: const TextStyle(color: SignaletTheme.warning, height: 1.4))],
      if (result.observations.isNotEmpty) ...[const SizedBox(height: 14), const Text('Visible observations', style: TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 6), ...result.observations.map((v) => _bullet(v))],
      if (result.entryZone != null) ...[const SizedBox(height: 14), const Text('Proposed levels — confirm manually', style: TextStyle(color: SignaletTheme.lime, fontWeight: FontWeight.w800)), _resultRow('Entry zone', '${result.entryZone!.low} – ${result.entryZone!.high}'), _resultRow('Stop-loss', '${result.stopLoss}'), _resultRow('Take-profit', '${result.takeProfit}')],
      const SizedBox(height: 12), _resultRow('Invalidation', result.invalidation),
      if (result.unreadableItems.isNotEmpty) ...[const SizedBox(height: 12), const Text('Unreadable items', style: TextStyle(fontWeight: FontWeight.w800)), ...result.unreadableItems.map(_bullet)],
      if (result.limitations.isNotEmpty) ...[const SizedBox(height: 12), const Text('Limitations', style: TextStyle(fontWeight: FontWeight.w800)), ...result.limitations.map(_bullet)],
      const SizedBox(height: 16),
      OutlinedButton.icon(onPressed: () => Clipboard.setData(ClipboardData(text: result.toCopyText())), icon: const Icon(Icons.copy), label: const Text('Copy summary')),
      const SizedBox(height: 8),
      const Text('This is unverified model output, not financial advice. Check the chart and trade levels in MT5. No automatic trading.', style: TextStyle(color: SignaletTheme.muted, fontSize: 11, height: 1.5)),
    ])));
  }
  Widget _resultRow(String label, String value) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(width: 124, child: Text(label, style: const TextStyle(color: SignaletTheme.muted, fontSize: 12))), Expanded(child: Text(value, style: const TextStyle(fontSize: 12, height: 1.35)))]));
  Widget _bullet(String value) => Padding(padding: const EdgeInsets.only(left: 4, top: 3, bottom: 3), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('•  ', style: TextStyle(color: SignaletTheme.lime)), Expanded(child: Text(value, style: const TextStyle(height: 1.4, fontSize: 12)))]));
}
