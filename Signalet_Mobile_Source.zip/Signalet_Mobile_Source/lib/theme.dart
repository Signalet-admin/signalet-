import 'package:flutter/material.dart';

class SignaletTheme {
  static const background = Color(0xFF090B0C);
  static const surface = Color(0xFF121619);
  static const surfaceAlt = Color(0xFF0D1112);
  static const border = Color(0xFF2A3033);
  static const lime = Color(0xFFA3E635);
  static const muted = Color(0xFF9AA1A5);
  static const warning = Color(0xFFF5B6B6);

  static ThemeData dark() {
    final scheme = const ColorScheme.dark(
      primary: lime,
      onPrimary: Colors.black,
      secondary: Color(0xFFB7C4C6),
      surface: surface,
      onSurface: Color(0xFFF2F4F4),
      error: Color(0xFFFF7878),
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: background,
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(
        backgroundColor: background,
        surfaceTintColor: Colors.transparent,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: border),
        ),
        margin: EdgeInsets.zero,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceAlt,
        labelStyle: const TextStyle(color: muted),
        hintStyle: const TextStyle(color: muted),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: lime, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: lime,
          foregroundColor: Colors.black,
          disabledBackgroundColor: const Color(0xFF343B2D),
          disabledForegroundColor: const Color(0xFF777D70),
          minimumSize: const Size.fromHeight(54),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFFE7E9EA),
          side: const BorderSide(color: border),
          minimumSize: const Size(48, 48),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: background,
        selectedItemColor: lime,
        unselectedItemColor: muted,
        type: BottomNavigationBarType.fixed,
      ),
      dividerColor: border,
    );
  }
}
