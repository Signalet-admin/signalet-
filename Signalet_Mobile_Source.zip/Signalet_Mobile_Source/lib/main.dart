import 'dart:async';

import 'package:flutter/material.dart';

import 'screens/history_screen.dart';
import 'screens/scan_screen.dart';
import 'screens/settings_screen.dart';
import 'services/app_controller.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(SignaletApp(controller: AppController()));
}

class SignaletApp extends StatefulWidget {
  const SignaletApp({super.key, required this.controller});
  final AppController controller;

  @override
  State<SignaletApp> createState() => _SignaletAppState();
}

class _SignaletAppState extends State<SignaletApp> {
  int _selectedTab = 0;

  @override
  void initState() {
    super.initState();
    unawaited(widget.controller.initialize());
  }

  @override
  void dispose() {
    widget.controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Signalet',
      debugShowCheckedModeBanner: false,
      theme: SignaletTheme.dark(),
      home: AnimatedBuilder(
        animation: widget.controller,
        builder: (context, _) => Scaffold(
          body: SafeArea(
            child: IndexedStack(
              index: _selectedTab,
              children: [
                ScanScreen(
                  controller: widget.controller,
                  onGoSettings: () => setState(() => _selectedTab = 2),
                ),
                HistoryScreen(controller: widget.controller),
                SettingsScreen(controller: widget.controller),
              ],
            ),
          ),
          bottomNavigationBar: NavigationBar(
            backgroundColor: SignaletTheme.background,
            indicatorColor: SignaletTheme.lime.withValues(alpha: 0.12),
            selectedIndex: _selectedTab,
            onDestinationSelected: (i) => setState(() => _selectedTab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.center_focus_strong_outlined), selectedIcon: Icon(Icons.center_focus_strong), label: 'Scan'),
              NavigationDestination(icon: Icon(Icons.history_rounded), label: 'History'),
              NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
            ],
          ),
        ),
      ),
    );
  }
}
