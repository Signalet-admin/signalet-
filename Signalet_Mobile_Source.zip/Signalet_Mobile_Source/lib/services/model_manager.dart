import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart' as crypto;
import 'package:flutter_edge_ai/flutter_edge_ai.dart';
import 'package:flutter_edge_ai_litertlm/flutter_edge_ai_litertlm.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'resumable_model_file_downloader.dart';

/// App-private model storage plus resumable, checksum-verified one-time download.
/// Inference never uses the network; the sole network path is explicit model setup.
class ModelManager {
  static const modelId = 'LLaVA-OneVision-0.5B';
  static const modelFilename = '$modelId.litertlm';
  static const modelUrl =
      'https://huggingface.co/litert-community/LLaVA-OneVision-0.5B/resolve/main/$modelFilename';
  static const modelSizeBytes = 829 * 1000 * 1000;
  static const expectedSha256 =
      '7f7cd7ae3d2ae435a1f69651de02a9d51e916be60fdfef5cadc721725310971a';

  ModelState _state = ModelState.notInstalled;
  ModelState get state => _state;
  set state(ModelState next) {
    if (!modelStateCanTransition(_state, next)) {
      throw StateError('Illegal model state transition: ${_state.name} -> ${next.name}');
    }
    _state = next;
  }

  int progressPercent = 0;
  int downloadedBytes = 0;
  int totalDownloadBytes = modelSizeBytes;
  String? error;
  bool _initialized = false;
  Future<void>? _runtimeInitialization;
  Future<void>? _operation;

  bool get isReady => state == ModelState.ready;

  Future<File> _modelFile() async {
    final support = await getApplicationSupportDirectory();
    return File(p.join(support.path, 'local_models', modelFilename));
  }

  Future<File> _partialFile() async {
    final model = await _modelFile();
    return File('${model.path}.part');
  }

  Future<void> initialize() async {
    try {
      await _ensureRuntime();
      final installed = await FlutterEdgeAi.isModelInstalled(modelId);
      if (!installed) {
        state = ModelState.notInstalled;
        return;
      }
      state = ModelState.checking;
      // fromFile models remain in app-private storage and getModelPath resolves
      // their registered path. The app-owned path is also checked for recovery.
      final path = await FlutterEdgeAi.getModelPath(modelFilename);
      final file = File(path);
      if (!await file.exists()) {
        state = ModelState.notInstalled;
        error = 'The model record exists, but its file is missing. Download it again.';
        return;
      }
      if (!await _hasValidVerificationMarker(file)) {
        final actualHash = await _sha256OfFile(file);
        if (actualHash != expectedSha256) {
          state = ModelState.error;
          error = 'The installed model failed its SHA-256 integrity check. Delete it and download again.';
          return;
        }
        await _smokeTest();
        await _writeVerificationMarker(file);
      }
      state = ModelState.ready;
      error = null;
    } catch (e) {
      if (state != ModelState.error) state = ModelState.error;
      error = _explain(e);
    }
  }

  Future<void> downloadAndInstall({required void Function(int) onProgress}) async {
    // Guard against two UI surfaces starting overlapping model operations.
    final pending = _operation;
    if (pending != null) {
      await pending;
      if (state == ModelState.ready) {
        onProgress(100);
        return;
      }
      throw StateError(error ?? 'The model operation failed. Retry from Settings.');
    }
    final operation = _downloadAndInstallOnce(onProgress: onProgress);
    _operation = operation;
    try {
      await operation;
    } finally {
      if (identical(_operation, operation)) _operation = null;
    }
  }

  Future<void> _downloadAndInstallOnce({required void Function(int) onProgress}) async {
    state = ModelState.downloading;
    progressPercent = 0;
    downloadedBytes = 0;
    totalDownloadBytes = modelSizeBytes;
    error = null;
    try {
      await _ensureRuntime();

      // Reuse a known-good active installation without needlessly transferring
      // 829 MB again. A bad installed record is removed before repair.
      if (await FlutterEdgeAi.isModelInstalled(modelId)) {
        final installedPath = await FlutterEdgeAi.getModelPath(modelFilename);
        final installedFile = File(installedPath);
        if (await installedFile.exists() && await _fileIsVerified(installedFile)) {
          state = ModelState.checking;
          if (!await _hasValidVerificationMarker(installedFile)) {
            await _smokeTest();
            await _writeVerificationMarker(installedFile);
          }
          state = ModelState.ready;
          progressPercent = 100;
          downloadedBytes = await installedFile.length();
          totalDownloadBytes = downloadedBytes;
          error = null;
          onProgress(100);
          return;
        }
        await FlutterEdgeAi.uninstallModel(modelId);
      }

      final file = await _downloadVerifiedModel(onProgress: onProgress);
      state = ModelState.checking;
      final installation = await FlutterEdgeAi.installModel(
        modelType: ModelType.general,
        fileType: ModelFileType.litertlm,
      ).fromFile(file.path).install();

      if (installation.modelId != modelId) {
        await FlutterEdgeAi.uninstallModel(installation.modelId);
        throw StateError('Runtime installed an unexpected model ID: ${installation.modelId}');
      }
      final registeredPath = await FlutterEdgeAi.getModelPath(modelFilename);
      final registeredFile = File(registeredPath);
      if (!await registeredFile.exists() || await registeredFile.length() == 0) {
        await FlutterEdgeAi.uninstallModel(modelId);
        throw StateError('The runtime registered a missing or empty model file. Retry setup.');
      }
      // The downloader already verified the pinned digest. fromFile is documented
      // to keep the app-owned file in place; if the runtime resolves a different
      // path, verify that copy before running the smoke test.
      if (p.normalize(registeredFile.absolute.path) != p.normalize(file.absolute.path) &&
          await _sha256OfFile(registeredFile) != expectedSha256) {
        await FlutterEdgeAi.uninstallModel(modelId);
        throw StateError('The runtime-resolved model failed its post-install integrity check. Retry setup.');
      }
      await _smokeTest();
      await _writeVerificationMarker(registeredFile);
      state = ModelState.ready;
      progressPercent = 100;
      downloadedBytes = await registeredFile.length();
      totalDownloadBytes = downloadedBytes;
      error = null;
      onProgress(100);
    } catch (e) {
      if (state != ModelState.error) state = ModelState.error;
      error = _explain(e);
      rethrow;
    }
  }

  /// Resume interrupted HTTPS transfers in app-private storage and activate
  /// the model only after SHA-256 verification.
  Future<File> _downloadVerifiedModel({required void Function(int) onProgress}) async {
    final destination = await _modelFile();
    final downloader = ResumableModelFileDownloader(
      uri: Uri.parse(modelUrl),
      expectedSha256: expectedSha256,
      expectedSizeBytes: modelSizeBytes,
    );
    return downloader.download(
      destination: destination,
      onProgress: (bytes, total, percent) {
        downloadedBytes = bytes;
        totalDownloadBytes = total;
        progressPercent = percent;
        onProgress(percent);
      },
    );
  }

  Future<void> deleteModel() async {
    try {
      state = ModelState.deleting;
      String? registeredPath;
      if (await FlutterEdgeAi.isModelInstalled(modelId)) {
        registeredPath = await FlutterEdgeAi.getModelPath(modelFilename);
      }
      if (FlutterEdgeAi.hasActiveModel()) {
        final model = await FlutterEdgeAi.getActiveModel(
          maxTokens: 2048,
          supportImage: true,
          preferredBackend: PreferredBackend.cpu,
        );
        await model.close();
      }
      await FlutterEdgeAi.uninstallModel(modelId);
      final file = await _modelFile();
      if (await file.exists()) await file.delete();
      final partial = await _partialFile();
      if (await partial.exists()) await partial.delete();
      final markerPaths = <String>{file.path};
      if (registeredPath != null) markerPaths.add(registeredPath);
      for (final modelPath in markerPaths) {
        final marker = File('$modelPath.signalet-verified.json');
        if (await marker.exists()) await marker.delete();
      }
      state = ModelState.notInstalled;
      progressPercent = 0;
      downloadedBytes = 0;
      totalDownloadBytes = modelSizeBytes;
      error = null;
    } catch (e) {
      if (state != ModelState.error) state = ModelState.error;
      error = _explain(e);
      rethrow;
    }
  }

  Future<void> ensureReady() async {
    if (state == ModelState.ready) return;
    await _ensureRuntime();
    final installed = await FlutterEdgeAi.isModelInstalled(modelId);
    if (!installed) {
      if (state != ModelState.notInstalled && modelStateCanTransition(state, ModelState.notInstalled)) {
        state = ModelState.notInstalled;
      }
      throw StateError('Download the local model in Settings before analysing.');
    }
    if (state != ModelState.checking) state = ModelState.checking;
    try {
      final path = await FlutterEdgeAi.getModelPath(modelFilename);
      final file = File(path);
      if (!await file.exists()) {
        state = ModelState.notInstalled;
        throw StateError('The local model file is missing. Download it again.');
      }
      if (!await _hasValidVerificationMarker(file)) {
        final actualHash = await _sha256OfFile(file);
        if (actualHash != expectedSha256) {
          state = ModelState.error;
          throw StateError('The local model failed its integrity check. Delete and download it again.');
        }
        await _smokeTest();
        await _writeVerificationMarker(file);
      }
      state = ModelState.ready;
      error = null;
    } catch (e) {
      if (state == ModelState.checking) state = ModelState.error;
      error = _explain(e);
      rethrow;
    }
  }

  Future<int> installedModelStorageBytes() async {
    final file = await _modelFile();
    if (await file.exists()) return file.length();
    if (await FlutterEdgeAi.isModelInstalled(modelId)) {
      final path = await FlutterEdgeAi.getModelPath(modelFilename);
      final installed = File(path);
      if (await installed.exists()) return installed.length();
    }
    return 0;
  }

  Future<File> _verificationMarkerFile(File modelFile) async =>
      File('${modelFile.path}.signalet-verified.json');

  /// Full SHA-256 runs at download time and when file metadata no longer matches
  /// the successful-install marker, not before every chart scan.
  Future<bool> _hasValidVerificationMarker(File modelFile) async {
    try {
      final marker = await _verificationMarkerFile(modelFile);
      if (!await marker.exists()) return false;
      final decoded = jsonDecode(await marker.readAsString());
      if (decoded is! Map<String, dynamic> ||
          decoded['model_id'] != modelId ||
          decoded['sha256'] != expectedSha256 ||
          decoded['smoke_test_passed'] != true) {
        return false;
      }
      final stat = await modelFile.stat();
      return decoded['size_bytes'] == stat.size &&
          decoded['modified_ms'] == stat.modified.millisecondsSinceEpoch;
    } catch (_) {
      return false;
    }
  }

  Future<bool> _fileIsVerified(File file) async {
    if (!await file.exists()) return false;
    if (await _hasValidVerificationMarker(file)) return true;
    return await _sha256OfFile(file) == expectedSha256;
  }

  Future<void> _writeVerificationMarker(File modelFile) async {
    final stat = await modelFile.stat();
    final marker = await _verificationMarkerFile(modelFile);
    await marker.writeAsString(jsonEncode({
      'model_id': modelId,
      'sha256': expectedSha256,
      'size_bytes': stat.size,
      'modified_ms': stat.modified.millisecondsSinceEpoch,
      'smoke_test_passed': true,
    }), flush: true);
  }

  Future<void> _ensureRuntime() async {
    if (_initialized) return;
    final pending = _runtimeInitialization;
    if (pending != null) {
      await pending;
      return;
    }
    final initialization = FlutterEdgeAi.initialize(
      inferenceEngines: const [LiteRtLmEngine()],
    );
    _runtimeInitialization = initialization;
    try {
      await initialization;
      _initialized = true;
    } catch (_) {
      _runtimeInitialization = null;
      rethrow;
    }
  }

  Future<void> _smokeTest() async {
    final model = await FlutterEdgeAi.getActiveModel(
      maxTokens: 2048,
      supportImage: true,
      preferredBackend: PreferredBackend.cpu,
    );
    try {
      final chat = await model.createChat(supportImage: true, maxOutputTokens: 12);
      final sampleImage = base64Decode(
        'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAGUlEQVR4nGNsaGhgIAUwkaR6VMOohiGlAQDJTAGgLgFHggAAAABJRU5ErkJggg==',
      );
      await chat.addQueryChunk(Message.withImages(
        text: 'Describe the simple gray square in one short sentence.',
        imageBytes: [sampleImage],
        isUser: true,
      ));
      final output = StringBuffer();
      await for (final response in chat.generateChatResponseAsync()) {
        if (response is TextResponse) output.write(response.token);
      }
      if (output.toString().trim().isEmpty) {
        throw StateError('The model loaded but returned an empty sample response.');
      }
    } finally {
      await model.close();
    }
  }

  Future<String> _sha256OfFile(File file) async {
    final digest = await crypto.sha256.bind(file.openRead()).first;
    return digest.toString();
  }

  String _explain(Object error) {
    final text = error.toString();
    if (text.toLowerCase().contains('space') || text.toLowerCase().contains('storage')) {
      return 'Not enough storage for the model. Free at least 2 GB and retry.';
    }
    if (text.toLowerCase().contains('memory') || text.toLowerCase().contains('alloc')) {
      return 'This phone may not have enough available memory for this model. Close other apps and retry; if it repeats, the device may be unsupported.';
    }
    return 'Model setup failed: $text';
  }
}

enum ModelState { notInstalled, downloading, checking, ready, deleting, error }

bool modelStateCanTransition(ModelState from, ModelState to) {
  if (from == to) return true;
  return switch (from) {
    ModelState.notInstalled => {ModelState.checking, ModelState.downloading, ModelState.error, ModelState.deleting}.contains(to),
    ModelState.downloading => {ModelState.checking, ModelState.error, ModelState.notInstalled}.contains(to),
    ModelState.checking => {ModelState.ready, ModelState.error, ModelState.notInstalled, ModelState.downloading}.contains(to),
    ModelState.ready => {ModelState.checking, ModelState.downloading, ModelState.deleting, ModelState.error}.contains(to),
    ModelState.deleting => {ModelState.notInstalled, ModelState.error}.contains(to),
    ModelState.error => {ModelState.checking, ModelState.notInstalled, ModelState.downloading, ModelState.deleting, ModelState.ready}.contains(to),
  };
}
