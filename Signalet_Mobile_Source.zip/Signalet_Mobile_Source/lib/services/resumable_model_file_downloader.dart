import 'dart:io';

import 'package:crypto/crypto.dart' as crypto;

/// Resumable downloader for a single public model file.
///
/// It only writes to the caller-supplied app-private destination and its `.part`
/// sibling. It follows normal HTTPS redirects, requests identity encoding so
/// byte ranges remain stable, and only renames a file after SHA-256 verification.
class ResumableModelFileDownloader {
  ResumableModelFileDownloader({
    required this.uri,
    required this.expectedSha256,
    required this.expectedSizeBytes,
    HttpClient Function()? clientFactory,
  }) : _clientFactory = clientFactory ?? HttpClient.new;

  final Uri uri;
  final String expectedSha256;
  final int expectedSizeBytes;
  final HttpClient Function() _clientFactory;

  Future<File> download({
    required File destination,
    required void Function(int downloadedBytes, int totalBytes, int percent) onProgress,
  }) async {
    await destination.parent.create(recursive: true);
    final partial = File('${destination.path}.part');

    if (await destination.exists()) {
      if (await _sha256OfFile(destination) == expectedSha256) {
        final size = await destination.length();
        onProgress(size, size, 100);
        return destination;
      }
      await destination.delete();
    }

    if (await partial.exists()) {
      final size = await partial.length();
      if (size > expectedSizeBytes * 2) {
        await partial.delete();
      } else if (size > 0 && await _sha256OfFile(partial) == expectedSha256) {
        // A process may have stopped after the final byte arrived but before
        // the successful download was atomically renamed into place.
        return partial.rename(destination.path);
      }
    }

    final client = _clientFactory()
      ..connectionTimeout = const Duration(seconds: 30)
      ..idleTimeout = const Duration(seconds: 60)
      ..maxConnectionsPerHost = 1;
    var lastError = 'The model download did not complete.';
    try {
      // One retry is reserved for a server that rejects or misreports a Range
      // request. Ordinary network errors keep the partial file for the next
      // user-initiated retry, avoiding a silent restart of hundreds of MB.
      for (var attempt = 0; attempt < 2; attempt++) {
        final existing = await partial.exists() ? await partial.length() : 0;
        var totalBytes = expectedSizeBytes;
        var currentBytes = existing;
        // Surface the persisted partial immediately, even if the next network
        // connection attempt fails before response headers arrive.
        final savedPercent = ((existing / totalBytes) * 100).floor().clamp(0, 99).toInt();
        onProgress(existing, totalBytes, savedPercent);
        final request = await client.getUrl(uri);
        request.followRedirects = true;
        request.headers.set(HttpHeaders.acceptEncodingHeader, 'identity');
        request.headers.set(HttpHeaders.userAgentHeader, 'Signalet/1.0 model-setup');
        if (existing > 0) request.headers.set(HttpHeaders.rangeHeader, 'bytes=$existing-');
        final response = await request.close();

        if (response.statusCode == HttpStatus.requestedRangeNotSatisfiable && existing > 0) {
          await response.drain<void>();
          await partial.delete();
          onProgress(0, expectedSizeBytes, 0);
          lastError = 'The server rejected the saved resume offset; restarting the download.';
          continue;
        }
        final resumed = response.statusCode == HttpStatus.partialContent;
        if (response.statusCode != HttpStatus.ok && !resumed) {
          final status = response.statusCode;
          await response.drain<void>();
          throw HttpException('Model host returned HTTP $status.', uri: uri);
        }

        final contentRange = response.headers.value(HttpHeaders.contentRangeHeader);
        final rangeMatch = contentRange == null
            ? null
            : RegExp(r'^bytes (\d+)-(\d+)/(\d+|\*)$').firstMatch(contentRange.trim());
        if (resumed &&
            (rangeMatch == null || int.tryParse(rangeMatch.group(1)!) != existing)) {
          await response.drain<void>();
          if (attempt == 0) {
            await partial.delete();
            onProgress(0, expectedSizeBytes, 0);
            lastError = 'The server returned an invalid byte range; restarting from the beginning.';
            continue;
          }
          throw HttpException('Model host returned an invalid byte range.', uri: uri);
        }
        if (resumed && rangeMatch != null && rangeMatch.group(3) != '*') {
          totalBytes = int.parse(rangeMatch.group(3)!);
        } else if (!resumed && response.contentLength > 0) {
          totalBytes = response.contentLength;
        }
        if (totalBytes <= 0) totalBytes = expectedSizeBytes;
        final expectedResponseBytes = response.contentLength;
        final startBytes = resumed ? existing : 0;
        currentBytes = startBytes;
        final initialPercent = ((currentBytes / totalBytes) * 100).floor().clamp(0, 100).toInt();
        onProgress(currentBytes, totalBytes, initialPercent);
        final raf = await partial.open(mode: resumed ? FileMode.append : FileMode.write);
        var lastReportedBytes = currentBytes - 1024 * 1024;
        var lastReportedPercent = initialPercent;
        try {
          await for (final chunk in response) {
            await raf.writeFrom(chunk);
            currentBytes += chunk.length;
            final percent = ((currentBytes / totalBytes) * 100).floor().clamp(0, 100).toInt();
            if (percent != lastReportedPercent || currentBytes - lastReportedBytes >= 1024 * 1024) {
              onProgress(currentBytes, totalBytes, percent);
              lastReportedBytes = currentBytes;
              lastReportedPercent = percent;
            }
          }
          await raf.flush();
        } finally {
          await raf.close();
        }

        if (expectedResponseBytes >= 0 && currentBytes - startBytes != expectedResponseBytes) {
          throw const HttpException('The model download was interrupted. Retry to resume from saved bytes.');
        }
        if (resumed && rangeMatch != null && rangeMatch.group(3) != '*' &&
            currentBytes != int.parse(rangeMatch.group(3)!)) {
          throw const HttpException('The model download is incomplete. Retry to resume from saved bytes.');
        }

        final actualHash = await _sha256OfFile(partial);
        if (actualHash != expectedSha256) {
          if (currentBytes >= totalBytes) {
            await partial.delete();
            currentBytes = 0;
          }
          throw StateError('SHA-256 verification failed; the model was not installed. Retry the download.');
        }

        if (await destination.exists()) await destination.delete();
        final finished = await partial.rename(destination.path);
        final finalSize = await finished.length();
        onProgress(finalSize, finalSize, 100);
        return finished;
      }
      throw StateError(lastError);
    } finally {
      client.close(force: true);
    }
  }

  Future<String> _sha256OfFile(File file) async =>
      (await crypto.sha256.bind(file.openRead()).first).toString();
}
