import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;

import '../models/signal_result.dart';
import 'analysis_service.dart';
import 'local_history.dart';
import 'model_manager.dart';
import 'preferences_store.dart';

class AppController extends ChangeNotifier {
  final ModelManager modelManager = ModelManager();
  final LocalHistory historyStore = LocalHistory();
  final PreferencesStore preferences = PreferencesStore();
  late final AnalysisService analysis = AnalysisService(modelManager);

  bool initialized = false;
  bool _disposed = false;
  bool initializationFailed = false;
  bool modelOperationInProgress = false;
  bool analysisInProgress = false;
  String? initializationError;
  bool saveScreenshotThumbnails = false;
  double defaultRiskPercent = 0.25;
  List<HistoryEntry> history = [];
  String? lastAnalysisError;
  Future<void>? _initialization;

  Future<void> initialize() => _initialization ??= _initializeOnce();

  Future<void> _initializeOnce() async {
    try {
      try {
        await modelManager.initialize();
        if (modelManager.state == ModelState.error) {
          initializationFailed = true;
          initializationError = modelManager.error;
        }
      } catch (e) {
        initializationFailed = true;
        initializationError = e.toString();
      }

      try {
        saveScreenshotThumbnails = await preferences.saveScreenshots();
        defaultRiskPercent =
            (await preferences.defaultRisk()).clamp(0.05, 1.0).toDouble();
      } catch (e) {
        initializationFailed = true;
        initializationError ??= 'Could not load preferences: $e';
        saveScreenshotThumbnails = false;
        defaultRiskPercent = 0.25;
      }

      try {
        history = await historyStore.load();
      } catch (e) {
        initializationFailed = true;
        initializationError ??= 'Could not load local history: $e';
        history = [];
      }
    } finally {
      // Even if a local store is unavailable, leave the UI accessible so the
      // user can see the error and retry supported operations.
      initialized = true;
      _notifyListeners();
    }
  }

  Future<void> downloadModel(void Function(int) progress) async {
    if (analysisInProgress || modelOperationInProgress) {
      throw StateError('Wait for the current analysis or model operation to finish.');
    }
    modelOperationInProgress = true;
    _notifyListeners();
    try {
      await modelManager.downloadAndInstall(onProgress: progress);
      lastAnalysisError = null;
    } finally {
      modelOperationInProgress = false;
      _notifyListeners();
    }
  }

  Future<void> deleteModel() async {
    if (analysisInProgress || modelOperationInProgress) {
      throw StateError('Wait for the current analysis or model operation to finish.');
    }
    modelOperationInProgress = true;
    _notifyListeners();
    try {
      await modelManager.deleteModel();
    } finally {
      modelOperationInProgress = false;
      _notifyListeners();
    }
  }

  void beginAnalysis() {
    if (modelOperationInProgress || analysisInProgress) {
      throw StateError('Wait for the current operation to finish.');
    }
    analysisInProgress = true;
    _notifyListeners();
  }

  void endAnalysis() {
    if (!analysisInProgress) return;
    analysisInProgress = false;
    _notifyListeners();
  }

  Future<void> setSaveScreenshotThumbnails(bool value) async {
    saveScreenshotThumbnails = value;
    await preferences.setSaveScreenshots(value);
    if (!value) await historyStore.deleteSavedScreenshots();
    history = await historyStore.load();
    _notifyListeners();
  }

  Future<void> setDefaultRisk(double value) async {
    defaultRiskPercent = value;
    await preferences.setDefaultRisk(value);
    _notifyListeners();
  }

  Future<void> recordResult({
    required SignalResult result,
    required List<int> imageBytes,
  }) async {
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    String? savedPath;
    if (saveScreenshotThumbnails) {
      // Keep history lightweight: save a real local thumbnail, not a second
      // full-resolution chart screenshot. The original remains in scan memory
      // only and is never copied to permanent storage by default.
      try {
        final decoded = img.decodeImage(Uint8List.fromList(imageBytes));
        if (decoded != null) {
          final thumbnail = decoded.width > 480
              ? img.copyResize(decoded, width: 480)
              : decoded;
          final thumbnailBytes = img.encodeJpg(thumbnail, quality: 78);
          savedPath = await historyStore.saveScreenshot(
            thumbnailBytes,
            id,
            extension: '.jpg',
          );
        }
      } catch (_) {
        // A failed thumbnail conversion must not discard an otherwise valid
        // scan result or cause a fake screenshot to appear in history.
        savedPath = null;
      }
    }
    await historyStore.add(HistoryEntry(
      id: id,
      timestamp: DateTime.now(),
      symbol: result.symbol,
      timeframe: result.timeframe,
      status: result.status,
      summary: result.setupReason,
      screenshotPath: savedPath,
    ));
    history = await historyStore.load();
    _notifyListeners();
  }

  Future<void> deleteHistoryEntry(String id) async {
    await historyStore.delete(id);
    history = await historyStore.load();
    _notifyListeners();
  }

  Future<void> clearHistory() async {
    await historyStore.clear();
    history = [];
    _notifyListeners();
  }

  void _notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }

  Future<int> savedScreenshotBytes() => historyStore.screenshotsStorageBytes();
}
