/// Computes a cash-risk reference only. This deliberately does not calculate lot size.
double riskAmount(double balance, double riskPercent) {
  if (!balance.isFinite || balance <= 0) {
    throw ArgumentError.value(balance, 'balance', 'Must be a finite positive amount.');
  }
  if (!riskPercent.isFinite || riskPercent <= 0 || riskPercent > 100) {
    throw ArgumentError.value(riskPercent, 'riskPercent', 'Must be greater than 0 and no more than 100.');
  }
  return balance * (riskPercent / 100);
}
