import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/signal_result.dart';

class HistoryEntry {
  const HistoryEntry({
    required this.id,
    required this.timestamp,
    required this.symbol,
    required this.timeframe,
    required this.status,
    required this.summary,
    this.screenshotPath,
  });

  final String id;
  final DateTime timestamp;
  final String symbol;
  final String timeframe;
  final SignalStatus status;
  final String summary;
  final String? screenshotPath;

  Map<String, dynamic> toJson() => {
        'id': id,
        'timestamp': timestamp.toIso8601String(),
        'symbol': symbol,
        'timeframe': timeframe,
        'status': status.name,
        'summary': summary,
        'screenshot_path': screenshotPath,
      };

  factory HistoryEntry.fromJson(Map<String, dynamic> j) => HistoryEntry(
        id: j['id'] as String,
        timestamp: DateTime.tryParse(j['timestamp'] as String? ?? '') ?? DateTime.now(),
        symbol: j['symbol'] as String? ?? 'Unknown',
        timeframe: j['timeframe'] as String? ?? 'Unknown',
        status: SignalStatus.values.firstWhere(
          (v) => v.name == j['status'],
          orElse: () => SignalStatus.unableToRead,
        ),
        summary: j['summary'] as String? ?? '',
        screenshotPath: j['screenshot_path'] as String?,
      );
}

/// App-private history store. No network and no account/login data.
class LocalHistory {
  LocalHistory({Future<Directory> Function()? baseDirectoryProvider})
      : _baseDirectoryProvider = baseDirectoryProvider ?? getApplicationDocumentsDirectory;

  static const _filename = 'signalet_history_v1.json';
  final Future<Directory> Function() _baseDirectoryProvider;
  Future<Directory> get _directory => _baseDirectoryProvider();
  Future<File> get _historyFile async => File(p.join((await _directory).path, _filename));

  Future<List<HistoryEntry>> load() async {
    final file = await _historyFile;
    if (!await file.exists()) return [];
    try {
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! List) return [];
      return decoded
          .whereType<Map<String, dynamic>>()
          .map(HistoryEntry.fromJson)
          .toList()
        ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
    } catch (_) {
      // Corrupt history never produces a fake signal. Preserve file for manual recovery.
      return [];
    }
  }

  Future<void> add(HistoryEntry entry) async {
    final all = await load();
    all.insert(0, entry);
    await _write(all);
  }

  Future<void> delete(String id) async {
    final all = await load();
    final removed = all.where((e) => e.id == id).toList();
    for (final entry in removed) {
      final path = entry.screenshotPath;
      if (path != null) {
        final file = await _ownedScreenshotFile(path);
        if (file != null && await file.exists()) await file.delete();
      }
    }
    await _write(all.where((e) => e.id != id).toList());
  }

  Future<void> clear() async {
    final all = await load();
    for (final entry in all) {
      final path = entry.screenshotPath;
      if (path != null) {
        final file = await _ownedScreenshotFile(path);
        if (file != null && await file.exists()) await file.delete();
      }
    }
    await _write([]);
  }

  /// Restricts deletion to paths inside this app's saved_scans directory.
  /// A malformed/corrupt history JSON must not be able to delete unrelated files.
  Future<File?> _ownedScreenshotFile(String path) async {
    final root = p.normalize(p.absolute(p.join((await _directory).path, 'saved_scans')));
    final candidate = p.normalize(p.absolute(path));
    if (!p.isWithin(root, candidate)) return null;
    return File(candidate);
  }

  Future<String?> saveScreenshot(List<int> bytes, String id, {String extension = '.png'}) async {
    final directory = await _directory;
    final screenshots = Directory(p.join(directory.path, 'saved_scans'));
    if (!await screenshots.exists()) await screenshots.create(recursive: true);
    final file = File(p.join(screenshots.path, '$id$extension'));
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  Future<int> screenshotsStorageBytes() async {
    final directory = Directory(p.join((await _directory).path, 'saved_scans'));
    if (!await directory.exists()) return 0;
    var sum = 0;
    await for (final entity in directory.list(followLinks: false)) {
      if (entity is File) sum += await entity.length();
    }
    return sum;
  }

  Future<void> deleteSavedScreenshots() async {
    final directory = Directory(p.join((await _directory).path, 'saved_scans'));
    if (await directory.exists()) await directory.delete(recursive: true);
    final all = await load();
    await _write(all
        .map((e) => HistoryEntry(
              id: e.id,
              timestamp: e.timestamp,
              symbol: e.symbol,
              timeframe: e.timeframe,
              status: e.status,
              summary: e.summary,
            ))
        .toList());
  }

  Future<void> _write(List<HistoryEntry> entries) async {
    final file = await _historyFile;
    await file.writeAsString(jsonEncode(entries.map((e) => e.toJson()).toList()), flush: true);
  }
}
