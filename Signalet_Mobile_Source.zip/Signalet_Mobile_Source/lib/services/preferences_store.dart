import 'package:shared_preferences/shared_preferences.dart';

class PreferencesStore {
  static const _saveScreenshotsKey = 'saveScreenshotThumbnails';
  static const _defaultRiskKey = 'defaultRiskPercent';

  Future<bool> saveScreenshots() async =>
      (await SharedPreferences.getInstance()).getBool(_saveScreenshotsKey) ?? false;

  Future<void> setSaveScreenshots(bool value) async =>
      (await SharedPreferences.getInstance()).setBool(_saveScreenshotsKey, value);

  Future<double> defaultRisk() async =>
      (await SharedPreferences.getInstance()).getDouble(_defaultRiskKey) ?? 0.25;

  Future<void> setDefaultRisk(double value) async =>
      (await SharedPreferences.getInstance()).setDouble(_defaultRiskKey, value);
}
