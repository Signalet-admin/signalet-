import 'dart:typed_data';


import 'package:flutter_edge_ai/flutter_edge_ai.dart';

import '../models/signal_result.dart';
import 'model_manager.dart';

class AnalysisService {
  AnalysisService(this._modelManager);
  final ModelManager _modelManager;

  Future<SignalResult> analyze({
    required List<int> imageBytes,
    required String symbol,
    required String timeframe,
    required String? currentPrice,
    required String accountBalance,
    required String accountCurrency,
    required double riskPercent,
    required String strategy,
    required void Function(String stage) onStage,
    void Function(Future<void> Function()? cancelReady)? onCancelReady,
  }) async {
    if (imageBytes.isEmpty) {
      throw ArgumentError('The selected screenshot is empty. Choose another image.');
    }
    await _modelManager.ensureReady();
    onStage('Loading the on-device vision model');
    final model = await FlutterEdgeAi.getActiveModel(
      maxTokens: 2048,
      supportImage: true,
      preferredBackend: PreferredBackend.cpu,
    );
    try {
      // A new chat is created on every call. LLaVA-OneVision-0.5B is best
      // used with one image per conversation; no image history is reused.
      final chat = await model.createChat(supportImage: true, maxOutputTokens: 450);
      final prompt = _prompt(
        symbol: symbol,
        timeframe: timeframe,
        currentPrice: currentPrice,
        accountBalance: accountBalance,
        accountCurrency: accountCurrency,
        riskPercent: riskPercent,
        strategy: strategy,
      );
      onStage('Reading visible chart structure locally');
      await chat.addQueryChunk(Message.withImages(
        text: prompt,
        imageBytes: [Uint8List.fromList(imageBytes)],
        isUser: true,
      ));
      onStage('Generating and validating the result on this phone');
      onCancelReady?.call(() async { await chat.stopGeneration(); });
      final raw = StringBuffer();
      await for (final response in chat.generateChatResponseAsync()) {
        if (response is TextResponse) raw.write(response.token);
      }
      final output = raw.toString().trim();
      if (output.isEmpty) {
        return SignalResult.parseAndValidate('', expectedSymbol: symbol, expectedTimeframe: timeframe);
      }
      return SignalResult.parseAndValidate(
        output,
        expectedSymbol: symbol,
        expectedTimeframe: timeframe,
      );
    } finally {
      onCancelReady?.call(null);
      await model.close();
    }
  }

  String _prompt({
    required String symbol,
    required String timeframe,
    required String? currentPrice,
    required String accountBalance,
    required String accountCurrency,
    required double riskPercent,
    required String strategy,
  }) {
    final currentPriceText = (currentPrice?.trim().isNotEmpty ?? false)
        ? 'User-entered current price (not independently verified): ${currentPrice!.trim()}'
        : 'Current price was not supplied. Do not guess it from small or unreadable axis labels.';
    return '''You are a cautious visual chart assistant, not an execution system. Analyse exactly one supplied MT5 screenshot. Work only from visible evidence and do not invent numbers, candle details, price-axis values, indicators, or a current market price.

USER INPUTS (not connected to MT5; entered manually):
Symbol: $symbol
Timeframe: $timeframe
$currentPriceText
Account balance: ${accountBalance.trim().isEmpty ? 'not supplied' : accountBalance.trim()}
Account currency: ${accountCurrency.trim().isEmpty ? 'not supplied' : accountCurrency.trim()}
User risk limit per trade: $riskPercent% (context only; do not calculate lot size)
Strategy lens: $strategy

ANALYSIS RULES:
1. First decide if this is a Forex candlestick chart and whether the image is sharp/large enough to inspect. If not, status must be UNABLE_TO_READ or WAIT and explain why.
2. State directly visible facts first. Look for visible trend direction, visible swing highs/lows, possible HH/HL or LL/LH, range, pullback, visible support/resistance areas and contradictory evidence.
3. A BUY or SELL is allowed only when the chart visibly supports a coherent setup AND exact proposed price levels can be read/justified from the screenshot. If any required level is unreadable or doubtful, use WAIT and set entry_zone, stop_loss and take_profit to null.
4. Never create precise prices from an unreadable y-axis. Never use account balance or risk percent to invent a trade.
5. For BUY, require stop_loss < entry_zone.low <= entry_zone.high < take_profit. For SELL, require take_profit < entry_zone.low <= entry_zone.high < stop_loss. Otherwise use WAIT and null out all three levels.
6. Do not estimate confidence, probability or win rate. Do not state a trade is guaranteed or profitable.
7. Return ONLY one valid JSON object. No markdown fences, no text outside JSON. Use exactly these fields and types:
{
  "status": "BUY|SELL|WAIT|UNABLE_TO_READ",
  "symbol": "$symbol",
  "timeframe": "$timeframe",
  "observations": ["short directly visible observation"],
  "structure": "bullish|bearish|ranging|unclear",
  "pullback": "present|absent|unclear",
  "setup_reason": "brief evidence-based reason; explain WAIT when applicable",
  "entry_zone": null or {"low": number, "high": number},
  "stop_loss": null or number,
  "take_profit": null or number,
  "invalidation": "what visible condition would invalidate the idea, or why no trade should be taken",
  "unreadable_items": ["labels/levels that cannot be read"],
  "limitations": ["relevant image or model limitations"]
}
Use numeric JSON values only for prices you can actually justify from the screenshot. If the screenshot contradicts the supplied symbol/timeframe, report what is visibly identifiable in observations and set status WAIT. Do not claim access to live prices or connected MT5 data.''';
  }
}
