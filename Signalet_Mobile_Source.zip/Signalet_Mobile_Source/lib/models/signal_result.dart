import 'dart:convert';

enum SignalStatus { buy, sell, wait, unableToRead }

String signalStatusLabel(SignalStatus status) => switch (status) {
      SignalStatus.buy => 'BUY',
      SignalStatus.sell => 'SELL',
      SignalStatus.wait => 'WAIT',
      SignalStatus.unableToRead => 'UNABLE TO READ',
    };

enum Structure { bullish, bearish, ranging, unclear }

enum Pullback { present, absent, unclear }

class EntryZone {
  const EntryZone({required this.low, required this.high});
  final double low;
  final double high;

  Map<String, dynamic> toJson() => {'low': low, 'high': high};
}

class SignalResult {
  const SignalResult({
    required this.status,
    required this.symbol,
    required this.timeframe,
    required this.observations,
    required this.structure,
    required this.pullback,
    required this.setupReason,
    required this.entryZone,
    required this.stopLoss,
    required this.takeProfit,
    required this.invalidation,
    required this.unreadableItems,
    required this.limitations,
    required this.rawModelText,
    this.validationNote,
  });

  final SignalStatus status;
  final String symbol;
  final String timeframe;
  final List<String> observations;
  final Structure structure;
  final Pullback pullback;
  final String setupReason;
  final EntryZone? entryZone;
  final double? stopLoss;
  final double? takeProfit;
  final String invalidation;
  final List<String> unreadableItems;
  final List<String> limitations;
  final String rawModelText;
  final String? validationNote;

  bool get hasActionableLevels =>
      (status == SignalStatus.buy || status == SignalStatus.sell) &&
      entryZone != null && stopLoss != null && takeProfit != null;

  String toCopyText() {
    final lines = <String>[
      'Signalet local chart review',
      'Status: ${signalStatusLabel(status)}',
      'Symbol: $symbol',
      'Timeframe: $timeframe',
      'Structure: ${structure.name}',
      'Pullback: ${pullback.name}',
      'Reason: $setupReason',
      if (entryZone != null)
        'Proposed entry zone: ${entryZone!.low} – ${entryZone!.high}',
      if (stopLoss != null) 'Proposed stop-loss: $stopLoss',
      if (takeProfit != null) 'Proposed take-profit: $takeProfit',
      'Invalidation: $invalidation',
      if (observations.isNotEmpty) 'Observations: ${observations.join('; ')}',
      if (unreadableItems.isNotEmpty)
        'Unreadable: ${unreadableItems.join('; ')}',
      if (limitations.isNotEmpty) 'Limitations: ${limitations.join('; ')}',
      'Manual review required. Demo testing only. No MT5 connection or order execution.',
    ];
    return lines.join('\n');
  }

  Map<String, dynamic> toJson() => {
        'status': status.name,
        'symbol': symbol,
        'timeframe': timeframe,
        'observations': observations,
        'structure': structure.name,
        'pullback': pullback.name,
        'setup_reason': setupReason,
        'entry_zone': entryZone?.toJson(),
        'stop_loss': stopLoss,
        'take_profit': takeProfit,
        'invalidation': invalidation,
        'unreadable_items': unreadableItems,
        'limitations': limitations,
        'validation_note': validationNote,
      };

  factory SignalResult.fromJson(Map<String, dynamic> json) => SignalResult(
        status: _parseStatus(json['status']) ?? SignalStatus.unableToRead,
        symbol: _stringOrEmpty(json['symbol']),
        timeframe: _stringOrEmpty(json['timeframe']),
        observations: _stringList(json['observations']),
        structure: _parseStructure(json['structure']) ?? Structure.unclear,
        pullback: _parsePullback(json['pullback']) ?? Pullback.unclear,
        setupReason: _stringOrEmpty(json['setup_reason']),
        entryZone: _parseEntry(json['entry_zone']),
        stopLoss: _number(json['stop_loss']),
        takeProfit: _number(json['take_profit']),
        invalidation: _stringOrEmpty(json['invalidation']),
        unreadableItems: _stringList(json['unreadable_items']),
        limitations: _stringList(json['limitations']),
        rawModelText: '',
        validationNote: json['validation_note'] as String?,
      );

  static SignalResult parseAndValidate(
    String text, {
    required String expectedSymbol,
    required String expectedTimeframe,
  }) {
    try {
      final cleaned = _extractJson(text);
      final decoded = jsonDecode(cleaned);
      if (decoded is! Map<String, dynamic>) {
        return _unable('The model did not return a JSON object.', text,
            expectedSymbol, expectedTimeframe);
      }

      final status = _parseStatus(decoded['status']);
      final structure = _parseStructure(decoded['structure']);
      final pullback = _parsePullback(decoded['pullback']);
      final symbol = _stringOrEmpty(decoded['symbol']).trim();
      final timeframe = _stringOrEmpty(decoded['timeframe']).trim();
      final observations = _stringList(decoded['observations']);
      final unreadable = _stringList(decoded['unreadable_items']);
      final limitations = _stringList(decoded['limitations']);
      final reason = _stringOrEmpty(decoded['setup_reason']).trim();
      final invalidation = _stringOrEmpty(decoded['invalidation']).trim();

      if (status == null || structure == null || pullback == null ||
          symbol.isEmpty || timeframe.isEmpty || reason.isEmpty ||
          !decoded.containsKey('entry_zone') ||
          !decoded.containsKey('stop_loss') ||
          !decoded.containsKey('take_profit') ||
          !decoded.containsKey('observations') ||
          !decoded.containsKey('unreadable_items') ||
          !decoded.containsKey('limitations') ||
          !decoded.containsKey('invalidation') ||
          decoded['symbol'] is! String ||
          decoded['timeframe'] is! String ||
          decoded['setup_reason'] is! String ||
          decoded['invalidation'] is! String ||
          !_isStringList(decoded['observations']) ||
          !_isStringList(decoded['unreadable_items']) ||
          !_isStringList(decoded['limitations']) ||
          decoded['entry_zone'] != null && !_isValidEntryMap(decoded['entry_zone']) ||
          !_isNullableNumber(decoded['stop_loss']) ||
          !_isNullableNumber(decoded['take_profit'])) {
        return _unable('Required fields were missing or had invalid types.',
            text, expectedSymbol, expectedTimeframe);
      }

      var entry = _parseEntry(decoded['entry_zone']);
      var sl = _number(decoded['stop_loss']);
      var tp = _number(decoded['take_profit']);
      var validatedStatus = status;
      String? note;
      final symbolMatches = symbol.toUpperCase() == expectedSymbol.toUpperCase();
      final timeframeMatches = timeframe.toUpperCase() == expectedTimeframe.toUpperCase();

      if (!symbolMatches || !timeframeMatches) {
        validatedStatus = SignalStatus.wait;
        entry = null;
        sl = null;
        tp = null;
        note = 'The model output did not match the selected symbol/timeframe. Confirm the chart inputs.';
      } else if (status == SignalStatus.buy || status == SignalStatus.sell) {
        final structureAgrees = status == SignalStatus.buy
            ? structure == Structure.bullish
            : structure == Structure.bearish;
        final setupAgrees = structureAgrees && pullback == Pullback.present;
        final ordered = entry != null && sl != null && tp != null &&
            _validTradeLevels(status, entry, sl, tp);
        if (!setupAgrees) {
          validatedStatus = SignalStatus.wait;
          entry = null;
          sl = null;
          tp = null;
          note = 'The model did not confirm a matching directional structure and visible pullback. No trade levels are shown.';
        } else if (!ordered) {
          validatedStatus = SignalStatus.wait;
          entry = null;
          sl = null;
          tp = null;
          note = 'The model did not provide complete, positive and correctly ordered price levels. No trade levels are shown.';
        }
      } else {
        // Avoid implying levels are actionable for non-trade results.
        entry = null;
        sl = null;
        tp = null;
      }

      return SignalResult(
        status: validatedStatus,
        symbol: symbol,
        timeframe: timeframe,
        observations: observations,
        structure: structure,
        pullback: pullback,
        setupReason: reason,
        entryZone: entry,
        stopLoss: sl,
        takeProfit: tp,
        invalidation: invalidation,
        unreadableItems: unreadable,
        limitations: limitations,
        rawModelText: text,
        validationNote: note,
      );
    } catch (_) {
      return _unable('The model output could not be parsed as valid JSON.',
          text, expectedSymbol, expectedTimeframe);
    }
  }

  static bool _validTradeLevels(
      SignalStatus status, EntryZone entry, double sl, double tp) {
    if (!entry.low.isFinite || !entry.high.isFinite ||
        !sl.isFinite || !tp.isFinite ||
        entry.low <= 0 || entry.high <= 0 || sl <= 0 || tp <= 0 ||
        entry.low > entry.high) return false;
    if (status == SignalStatus.buy) {
      return sl < entry.low && tp > entry.high;
    }
    return tp < entry.low && sl > entry.high;
  }

  static String _extractJson(String source) {
    final noFence = source
        .replaceAll(RegExp(r'^\s*```(?:json)?\s*', caseSensitive: false), '')
        .replaceAll(RegExp(r'\s*```\s*$'), '')
        .trim();
    final start = noFence.indexOf('{');
    final end = noFence.lastIndexOf('}');
    if (start < 0 || end < start) throw const FormatException('No JSON object');
    return noFence.substring(start, end + 1);
  }

  static SignalResult _unable(String reason, String raw, String symbol, String timeframe) => SignalResult(
        status: SignalStatus.unableToRead,
        symbol: symbol,
        timeframe: timeframe,
        observations: const [],
        structure: Structure.unclear,
        pullback: Pullback.unclear,
        setupReason: reason,
        entryZone: null,
        stopLoss: null,
        takeProfit: null,
        invalidation: 'No trade should be taken from this output.',
        unreadableItems: const ['Model response could not be validated.'],
        limitations: const ['No numerical price levels were accepted. Review the chart manually.'],
        rawModelText: raw,
      );

  static SignalStatus? _parseStatus(dynamic value) => switch (value) {
        'BUY' => SignalStatus.buy,
        'SELL' => SignalStatus.sell,
        'WAIT' => SignalStatus.wait,
        'UNABLE_TO_READ' => SignalStatus.unableToRead,
        _ => null,
      };
  static Structure? _parseStructure(dynamic value) => switch (value) {
        'bullish' => Structure.bullish,
        'bearish' => Structure.bearish,
        'ranging' => Structure.ranging,
        'unclear' => Structure.unclear,
        _ => null,
      };
  static Pullback? _parsePullback(dynamic value) => switch (value) {
        'present' => Pullback.present,
        'absent' => Pullback.absent,
        'unclear' => Pullback.unclear,
        _ => null,
      };
  static bool _isStringList(dynamic v) => v is List && v.every((e) => e is String);
  static bool _isNullableNumber(dynamic v) => v == null || (v is num && v.isFinite);
  static bool _isValidEntryMap(dynamic v) {
    if (v is! Map<String, dynamic>) return false;
    return v['low'] is num && (v['low'] as num).isFinite &&
        v['high'] is num && (v['high'] as num).isFinite;
  }
  static String _stringOrEmpty(dynamic v) => v is String ? v : '';
  static List<String> _stringList(dynamic v) => v is List ? v.whereType<String>().toList() : <String>[];
  static double? _number(dynamic v) => v is num && v.isFinite ? v.toDouble() : null;
  static EntryZone? _parseEntry(dynamic v) {
    if (v == null || v is! Map<String, dynamic>) return null;
    final low = _number(v['low']);
    final high = _number(v['high']);
    if (low == null || high == null) return null;
    return EntryZone(low: low, high: high);
  }
}
