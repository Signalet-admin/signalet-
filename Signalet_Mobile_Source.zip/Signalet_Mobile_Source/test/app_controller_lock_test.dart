import 'package:flutter_test/flutter_test.dart';
import 'package:signalet/services/app_controller.dart';

void main() {
  test('a model download cannot start during analysis', () async {
    final controller = AppController();
    addTearDown(controller.dispose);
    controller.beginAnalysis();

    await expectLater(
      controller.downloadModel((_) {}),
      throwsA(isA<StateError>()),
    );
    expect(controller.analysisInProgress, isTrue);
    expect(controller.modelOperationInProgress, isFalse);
    controller.endAnalysis();
  });

  test('an analysis cannot start during a model operation', () {
    final controller = AppController();
    addTearDown(controller.dispose);
    controller.modelOperationInProgress = true;

    expect(controller.beginAnalysis, throwsA(isA<StateError>()));
    expect(controller.analysisInProgress, isFalse);
  });
}
