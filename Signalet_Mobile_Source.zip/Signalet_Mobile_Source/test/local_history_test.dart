import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:signalet/models/signal_result.dart';
import 'package:signalet/services/local_history.dart';

void main() {
  late Directory tempDirectory;
  late LocalHistory store;

  setUp(() async {
    tempDirectory = await Directory.systemTemp.createTemp('signalet-history-test-');
    store = LocalHistory(baseDirectoryProvider: () async => tempDirectory);
  });

  tearDown(() async {
    if (await tempDirectory.exists()) await tempDirectory.delete(recursive: true);
  });

  test('deleting an entry also deletes its stored screenshot', () async {
    final imagePath = await store.saveScreenshot([1, 2, 3, 4], 'scan1', extension: '.jpg');
    expect(imagePath, isNotNull);
    expect(await File(imagePath!).exists(), isTrue);
    await store.add(HistoryEntry(
      id: 'scan1', timestamp: DateTime(2026, 10, 18), symbol: 'EURUSD',
      timeframe: 'M15', status: SignalStatus.wait, summary: 'Unclear chart', screenshotPath: imagePath,
    ));
    await store.delete('scan1');
    expect(await store.load(), isEmpty);
    expect(await File(imagePath).exists(), isFalse);
  });

  test('deleting a record never deletes a path outside the owned screenshot folder', () async {
    final unrelatedFile = File('${tempDirectory.path}/important.txt');
    await unrelatedFile.writeAsString('keep this file');
    await store.add(HistoryEntry(
      id: 'unsafe-path',
      timestamp: DateTime(2026, 10, 18),
      symbol: 'EURUSD',
      timeframe: 'M15',
      status: SignalStatus.wait,
      summary: 'Corrupt/malicious local record',
      screenshotPath: unrelatedFile.path,
    ));

    await store.delete('unsafe-path');
    expect(await unrelatedFile.exists(), isTrue);
    expect(await unrelatedFile.readAsString(), 'keep this file');
  });

  test('clear removes all history and saved images', () async {
    final imagePath = await store.saveScreenshot([1, 2, 3], 'scan2');
    await store.add(HistoryEntry(
      id: 'scan2', timestamp: DateTime(2026, 10, 18), symbol: 'EURUSD',
      timeframe: 'M15', status: SignalStatus.unableToRead, summary: 'Image unreadable', screenshotPath: imagePath,
    ));
    await store.clear();
    expect(await store.load(), isEmpty);
    expect(await File(imagePath!).exists(), isFalse);
  });
}
