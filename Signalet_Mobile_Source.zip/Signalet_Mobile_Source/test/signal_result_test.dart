import 'package:flutter_test/flutter_test.dart';
import 'package:signalet/models/signal_result.dart';

void main() {
  const validBuy = '''{
    "status":"BUY",
    "symbol":"EURUSD",
    "timeframe":"M15",
    "observations":["Visible sequence of higher lows"],
    "structure":"bullish",
    "pullback":"present",
    "setup_reason":"A visible pullback within a bullish structure is present.",
    "entry_zone":{"low":1.1000,"high":1.1010},
    "stop_loss":1.0980,
    "take_profit":1.1060,
    "invalidation":"A new lower low below the visible swing invalidates this idea.",
    "unreadable_items":[],
    "limitations":["Current price is not live-verified"]
  }''';

  test('accepts BUY only when trade levels are correctly ordered', () {
    final result = SignalResult.parseAndValidate(validBuy, expectedSymbol: 'EURUSD', expectedTimeframe: 'M15');
    expect(result.status, SignalStatus.buy);
    expect(result.hasActionableLevels, isTrue);
    expect(result.stopLoss, lessThan(result.entryZone!.low));
    expect(result.takeProfit, greaterThan(result.entryZone!.high));
  });

  test('turns BUY into WAIT if stop-loss / take-profit order is invalid', () {
    final invalid = validBuy.replaceFirst('"stop_loss":1.0980', '"stop_loss":1.1040');
    final result = SignalResult.parseAndValidate(invalid, expectedSymbol: 'EURUSD', expectedTimeframe: 'M15');
    expect(result.status, SignalStatus.wait);
    expect(result.hasActionableLevels, isFalse);
    expect(result.entryZone, isNull);
    expect(result.stopLoss, isNull);
    expect(result.takeProfit, isNull);
    expect(result.validationNote, isNotNull);
  });

  test('rejects malformed model output instead of inventing a signal', () {
    final result = SignalResult.parseAndValidate('BUY EURUSD now!', expectedSymbol: 'EURUSD', expectedTimeframe: 'M15');
    expect(result.status, SignalStatus.unableToRead);
    expect(result.entryZone, isNull);
    expect(result.stopLoss, isNull);
    expect(result.takeProfit, isNull);
  });

  test('accepts SELL only when stop-loss and take-profit are on the correct sides', () {
    final sell = validBuy
        .replaceFirst('"status":"BUY"', '"status":"SELL"')
        .replaceFirst('"structure":"bullish"', '"structure":"bearish"')
        .replaceFirst('"stop_loss":1.0980', '"stop_loss":1.1030')
        .replaceFirst('"take_profit":1.1060', '"take_profit":1.0950');
    final result = SignalResult.parseAndValidate(sell, expectedSymbol: 'EURUSD', expectedTimeframe: 'M15');
    expect(result.status, SignalStatus.sell);
    expect(result.hasActionableLevels, isTrue);
    expect(result.takeProfit, lessThan(result.entryZone!.low));
    expect(result.stopLoss, greaterThan(result.entryZone!.high));
  });

  test('WAIT result never retains numerical trade levels', () {
    final wait = validBuy.replaceFirst('"status":"BUY"', '"status":"WAIT"');
    final result = SignalResult.parseAndValidate(wait, expectedSymbol: 'EURUSD', expectedTimeframe: 'M15');
    expect(result.status, SignalStatus.wait);
    expect(result.entryZone, isNull);
    expect(result.stopLoss, isNull);
    expect(result.takeProfit, isNull);
  });

  test('non-positive prices fail closed to WAIT', () {
    final invalid = validBuy.replaceFirst('"stop_loss":1.0980', '"stop_loss":0');
    final result = SignalResult.parseAndValidate(invalid, expectedSymbol: 'EURUSD', expectedTimeframe: 'M15');
    expect(result.status, SignalStatus.wait);
    expect(result.hasActionableLevels, isFalse);
    expect(result.entryZone, isNull);
  });

  test('BUY requires bullish structure and a visible pullback', () {
    final invalid = validBuy.replaceFirst('"pullback":"present"', '"pullback":"absent"');
    final result = SignalResult.parseAndValidate(invalid, expectedSymbol: 'EURUSD', expectedTimeframe: 'M15');
    expect(result.status, SignalStatus.wait);
    expect(result.entryZone, isNull);
    expect(result.stopLoss, isNull);
    expect(result.takeProfit, isNull);
    expect(result.validationNote, contains('directional structure'));
  });

  test('timeframe mismatch forces WAIT and drops proposed levels', () {
    final result = SignalResult.parseAndValidate(validBuy, expectedSymbol: 'EURUSD', expectedTimeframe: 'H1');
    expect(result.status, SignalStatus.wait);
    expect(result.entryZone, isNull);
    expect(result.stopLoss, isNull);
    expect(result.takeProfit, isNull);
  });

  test('symbol mismatch forces WAIT and drops proposed levels', () {
    final result = SignalResult.parseAndValidate(validBuy, expectedSymbol: 'GBPUSD', expectedTimeframe: 'M15');
    expect(result.status, SignalStatus.wait);
    expect(result.entryZone, isNull);
    expect(result.stopLoss, isNull);
    expect(result.takeProfit, isNull);
  });
}
