import 'package:flutter_test/flutter_test.dart';
import 'package:signalet/services/risk_math.dart';

void main() {
  test('computes cash-risk reference without lot sizing', () {
    expect(riskAmount(100000, 0.25), closeTo(250, 0.0001));
    expect(riskAmount(2000, 1), closeTo(20, 0.0001));
  });

  test('rejects invalid balance and risk inputs', () {
    expect(() => riskAmount(0, 0.25), throwsArgumentError);
    expect(() => riskAmount(1000, 0), throwsArgumentError);
    expect(() => riskAmount(1000, 101), throwsArgumentError);
  });
}
