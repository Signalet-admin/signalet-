import 'dart:io';

import 'package:crypto/crypto.dart' as crypto;
import 'package:flutter_test/flutter_test.dart';
import 'package:signalet/services/resumable_model_file_downloader.dart';

void main() {
  late Directory tempDirectory;
  late HttpServer server;
  late List<int> payload;
  late bool interruptFirstTransfer;
  late bool sawResumeRequest;

  setUp(() async {
    tempDirectory = await Directory.systemTemp.createTemp('signalet-download-test-');
    payload = List<int>.generate(128 * 1024, (i) => (i * 31 + 17) & 0xff);
    interruptFirstTransfer = true;
    sawResumeRequest = false;
    server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    server.listen((request) async {
      final response = request.response;
      final range = request.headers.value(HttpHeaders.rangeHeader);
      if (range == null && interruptFirstTransfer) {
        interruptFirstTransfer = false;
        response.statusCode = HttpStatus.ok;
        response.contentLength = payload.length;
        response.add(payload.sublist(0, payload.length ~/ 2));
        try {
          await response.close(); // Deliberately shorter than Content-Length.
        } catch (_) {
          // Some Dart HTTP server versions report the intentional truncation
          // at the server as well as exposing it to the client.
        }
        return;
      }
      if (range != null) {
        sawResumeRequest = true;
        final match = RegExp(r'^bytes=(\d+)-$').firstMatch(range);
        if (match == null) {
          response.statusCode = HttpStatus.badRequest;
          await response.close();
          return;
        }
        final start = int.parse(match.group(1)!);
        if (start >= payload.length) {
          response.statusCode = HttpStatus.requestedRangeNotSatisfiable;
          response.headers.set(HttpHeaders.contentRangeHeader, 'bytes */${payload.length}');
          await response.close();
          return;
        }
        response.statusCode = HttpStatus.partialContent;
        response.headers.set(
          HttpHeaders.contentRangeHeader,
          'bytes $start-${payload.length - 1}/${payload.length}',
        );
        response.contentLength = payload.length - start;
        response.add(payload.sublist(start));
        await response.close();
        return;
      }
      response.statusCode = HttpStatus.ok;
      response.contentLength = payload.length;
      response.add(payload);
      await response.close();
    });
  });

  tearDown(() async {
    await server.close(force: true);
    if (await tempDirectory.exists()) await tempDirectory.delete(recursive: true);
  });

  test('keeps partial bytes after interruption and resumes with HTTP Range', () async {
    final destination = File('${tempDirectory.path}/model.litertlm');
    final downloader = ResumableModelFileDownloader(
      uri: Uri.parse('http://${server.address.address}:${server.port}/model'),
      expectedSha256: crypto.sha256.convert(payload).toString(),
      expectedSizeBytes: payload.length,
    );

    await expectLater(
      downloader.download(destination: destination, onProgress: (_, __, ___) {}),
      throwsA(anything),
    );
    final partial = File('${destination.path}.part');
    expect(await partial.exists(), isTrue);
    expect(await partial.length(), greaterThan(0));
    expect(await partial.length(), lessThan(payload.length));

    final result = await downloader.download(
      destination: destination,
      onProgress: (_, __, ___) {},
    );
    expect(sawResumeRequest, isTrue);
    expect(await result.readAsBytes(), equals(payload));
    expect(await partial.exists(), isFalse);
  });

  test('does not promote a file whose checksum does not match', () async {
    interruptFirstTransfer = false;
    final destination = File('${tempDirectory.path}/bad-model.litertlm');
    final downloader = ResumableModelFileDownloader(
      uri: Uri.parse('http://${server.address.address}:${server.port}/model'),
      expectedSha256: '0' * 64,
      expectedSizeBytes: payload.length,
    );
    await expectLater(
      downloader.download(destination: destination, onProgress: (_, __, ___) {}),
      throwsStateError,
    );
    expect(await destination.exists(), isFalse);
    expect(await File('${destination.path}.part').exists(), isFalse);
  });
}
