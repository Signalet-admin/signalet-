import 'package:flutter_test/flutter_test.dart';
import 'package:signalet/services/model_manager.dart';

void main() {
  test('allows normal install, ready, and delete transitions', () {
    expect(modelStateCanTransition(ModelState.notInstalled, ModelState.downloading), isTrue);
    expect(modelStateCanTransition(ModelState.downloading, ModelState.checking), isTrue);
    expect(modelStateCanTransition(ModelState.checking, ModelState.ready), isTrue);
    expect(modelStateCanTransition(ModelState.ready, ModelState.deleting), isTrue);
    expect(modelStateCanTransition(ModelState.deleting, ModelState.notInstalled), isTrue);
    expect(modelStateCanTransition(ModelState.checking, ModelState.error), isTrue);
    expect(modelStateCanTransition(ModelState.error, ModelState.deleting), isTrue);
  });

  test('allows retries and rejects impossible transitions', () {
    expect(modelStateCanTransition(ModelState.error, ModelState.downloading), isTrue);
    expect(modelStateCanTransition(ModelState.downloading, ModelState.ready), isFalse);
    expect(modelStateCanTransition(ModelState.deleting, ModelState.downloading), isFalse);
  });
}
