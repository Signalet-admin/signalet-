#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo 'BLOCKED: Flutter SDK is not installed or not on PATH.' >&2
  exit 127
fi

cd "$(dirname "$0")/.."
if [[ ! -d android || ! -d ios ]]; then
  # Generate runner scaffolding in a temporary project rather than running
  # `flutter create .`, which can rewrite the application's pubspec or lib/.
  temporary_project="$(mktemp -d)"
  trap 'rm -rf "$temporary_project"' EXIT
  flutter create --platforms=android,ios --org com.signalet.app --project-name signalet "$temporary_project/signalet"
  if [[ ! -d android ]]; then
    cp -R "$temporary_project/signalet/android" ./android
  fi
  if [[ ! -d ios ]]; then
    cp -R "$temporary_project/signalet/ios" ./ios
  fi
  for generated_file in .metadata .gitignore analysis_options.yaml; do
    if [[ ! -f "$generated_file" && -f "$temporary_project/signalet/$generated_file" ]]; then
      cp "$temporary_project/signalet/$generated_file" "./$generated_file"
    fi
  done
fi

python3 tool/configure_platforms.py
flutter pub get
printf '\nPlatform scaffolding and dependencies are ready. Next run: flutter analyze && flutter test\n'
