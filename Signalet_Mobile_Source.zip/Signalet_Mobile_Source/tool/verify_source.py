#!/usr/bin/env python3
"""Static safety and packaging checks; intentionally not a Dart compiler."""
from pathlib import Path
import base64
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    'pubspec.yaml', '.gitignore', 'analysis_options.yaml', 'lib/main.dart',
    'lib/models/signal_result.dart',
    'lib/services/analysis_service.dart',
    'lib/services/model_manager.dart',
    'lib/services/resumable_model_file_downloader.dart',
    'lib/services/local_history.dart',
    'lib/screens/scan_screen.dart',
    'lib/screens/history_screen.dart',
    'lib/screens/settings_screen.dart',
    'lib/services/app_controller.dart',
    'docs/APP_SPEC.md', 'docs/ARCHITECTURE.md',
    'docs/MODEL_AND_REFERENCES.md', 'docs/TEST_CHECKLIST.md',
    'docs/SAFETY_AND_PRIVACY.md',
    'test/signal_result_test.dart', 'test/risk_math_test.dart',
    'test/model_state_machine_test.dart', 'test/local_history_test.dart',
    'test/resumable_model_file_downloader_test.dart',
    'test/app_controller_lock_test.dart',
    '.github/workflows/mobile-build.yml',
]
missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
if missing:
    print('FAIL: missing required files: ' + ', '.join(missing), file=sys.stderr)
    sys.exit(1)

analysis = (ROOT / 'lib/services/analysis_service.dart').read_text()
scan = (ROOT / 'lib/screens/scan_screen.dart').read_text()
settings = (ROOT / 'lib/screens/settings_screen.dart').read_text()
controller = (ROOT / 'lib/services/app_controller.dart').read_text()
manager = (ROOT / 'lib/services/model_manager.dart').read_text()
downloader = (ROOT / 'lib/services/resumable_model_file_downloader.dart').read_text()
history = (ROOT / 'lib/services/local_history.dart').read_text()
results = (ROOT / 'lib/models/signal_result.dart').read_text()
workflow = (ROOT / '.github/workflows/mobile-build.yml').read_text()

checks = {
    'actual image-plus-text inference call': 'Message.withImages(' in analysis,
    'fresh chat per screenshot': 'createChat(supportImage: true' in analysis,
    'streamed model output consumed': 'generateChatResponseAsync()' in analysis,
    'analysis service contains no remote inference URL': not re.search(r'https?://', analysis),
    'explicit model download URL exists only in model manager': 'huggingface.co/litert-community/LLaVA-OneVision-0.5B/resolve/main/' in manager,
    'model transfer supports byte-range resume and partial files': 'HttpHeaders.rangeHeader' in downloader and 'HttpStatus.partialContent' in downloader and ".part'" in downloader,
    'model file is checksum-verified before promotion': '_sha256OfFile(partial)' in downloader and 'partial.rename(destination.path)' in downloader,
    'model installer registers the verified app-private file': '.fromFile(file.path).install()' in manager,
    'verified model marker avoids re-hashing the full model on every scan': '_hasValidVerificationMarker(file)' in manager and 'modified_ms' in manager and 'smoke_test_passed' in manager,
    'analysis and model operations are mutually exclusive': 'beginAnalysis()' in controller and 'analysisInProgress || modelOperationInProgress' in controller,
    'history deletion is restricted to app-owned screenshot folder': '_ownedScreenshotFile' in history and 'p.isWithin(root, candidate)' in history,
    'pinned SHA-256 is 64 hex chars': bool(re.search(r"expectedSha256\s*=\s*\n?\s*'([0-9a-f]{64})'", manager)),
    'malformed model output fails closed': '_unable(' in results and 'SignalStatus.unableToRead' in results,
    'BUY/SELL levels checked for positive values and ordering': '_validTradeLevels' in results and 'entry.low <= 0' in results,
    'BUY/SELL requires matching trend structure and visible pullback': 'setupAgrees = structureAgrees && pullback == Pullback.present' in results,
    'workflow builds debug APK': 'flutter build apk --debug --target-platform android-arm64' in workflow,
    'workflow builds iOS simulator target without claiming signing': 'flutter build ios --simulator --debug' in workflow,
    'fractional slider clamp is explicitly converted to double': bool(re.search(r'\.clamp\(0?\.05,\s*1\.0\)\.toDouble\(\)', settings)) and bool(re.search(r'\.clamp\(0?\.05,\s*1\.0\)\.toDouble\(\)', scan)),
    'runtime initialization is deduplicated across startup/settings': '_runtimeInitialization' in manager and 'Future<void> initialize() => _initialization ??=' in controller,
    'local model storage stats are shown in settings': 'installedModelStorageBytes()' in manager and bool(re.search(r"_infoRow\(\s*'Installed model storage'", settings)),
    'temporary screenshot copy cleanup is implemented': '_deletePreviewFile' in scan and 'unawaited(_deletePreviewFile(previousPath))' in scan,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
if failed:
    print('Static checks failed.', file=sys.stderr)
    sys.exit(1)
print(f'PASS: required project files present ({len(REQUIRED)} checks)')
encoded_sample = re.search(r"final sampleImage = base64Decode\(\s*'([^']+)'\s*,?\s*\)", manager)
if not encoded_sample:
    print('FAIL: embedded smoke-test image is present', file=sys.stderr)
    sys.exit(1)
try:
    sample_bytes = base64.b64decode(encoded_sample.group(1), validate=True)
    png_ok = sample_bytes.startswith(b'\x89PNG\r\n\x1a\n') and len(sample_bytes) > 40
except Exception:
    png_ok = False
print(f"{'PASS' if png_ok else 'FAIL'}: smoke-test image is PNG-encoded bytes")
if not png_ok:
    sys.exit(1)

print('NOTE: these are source-structure checks, not compilation, Dart tests, or device acceptance tests.')
