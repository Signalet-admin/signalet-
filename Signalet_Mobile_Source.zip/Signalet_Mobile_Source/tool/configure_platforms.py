#!/usr/bin/env python3
"""Apply documented minimum platform settings after flutter create."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]

def replace_once(path: Path, pattern: str, repl: str, flags=0):
    text = path.read_text()
    new, count = re.subn(pattern, repl, text, count=1, flags=flags)
    if count:
        path.write_text(new)
        return True
    return False

def configure_android():
    manifest = ROOT / 'android/app/src/main/AndroidManifest.xml'
    if manifest.exists():
        text = manifest.read_text()
        # Keep the installed app label consistent across platforms.
        text = re.sub(r'android:label="[^"]+"', 'android:label="Signalet"', text, count=1)
        additions = []
        for permission in ['android.permission.INTERNET', 'android.permission.CAMERA']:
            if f'name="{permission}"' not in text:
                additions.append(f'    <uses-permission android:name="{permission}" />')
        if 'android.hardware.camera.any' not in text:
            additions.append('    <uses-feature android:name="android.hardware.camera.any" android:required="false" />')
        if additions:
            text = text.replace('<application', '\n'.join(additions) + '\n    <application', 1)
        manifest.write_text(text)

    gradle = ROOT / 'android/app/build.gradle.kts'
    if gradle.exists():
        text = gradle.read_text()
        text = text.replace('minSdk = flutter.minSdkVersion', 'minSdk = 30')
        text = text.replace('minSdkVersion flutter.minSdkVersion', 'minSdkVersion 30')
        if 'abiFilters' not in text and 'defaultConfig {' in text:
            text = text.replace('defaultConfig {', 'defaultConfig {\n        ndk { abiFilters += listOf("arm64-v8a") }', 1)
        gradle.write_text(text)
    groovy = ROOT / 'android/app/build.gradle'
    if groovy.exists():
        text = groovy.read_text()
        text = text.replace('minSdkVersion flutter.minSdkVersion', 'minSdkVersion 30')
        if 'abiFilters' not in text and 'defaultConfig {' in text:
            text = text.replace('defaultConfig {', 'defaultConfig {\n        ndk { abiFilters "arm64-v8a" }', 1)
        groovy.write_text(text)

def configure_ios():
    podfile = ROOT / 'ios/Podfile'
    if podfile.exists():
        text = podfile.read_text()
        if re.search(r"^platform :ios,", text, re.M):
            text = re.sub(r"^platform :ios,.*$", "platform :ios, '15.0'", text, count=1, flags=re.M)
        else:
            text = "platform :ios, '15.0'\n" + text
        if 'use_frameworks! :linkage => :static' not in text:
            text = text.replace("platform :ios, '15.0'", "platform :ios, '15.0'\nuse_frameworks! :linkage => :static", 1)
        podfile.write_text(text)

    info = ROOT / 'ios/Runner/Info.plist'
    if info.exists():
        text = info.read_text()
        if '<key>CFBundleDisplayName</key>' in text:
            text = re.sub(
                r'<key>CFBundleDisplayName</key>\s*<string>.*?</string>',
                '<key>CFBundleDisplayName</key>\n    <string>Signalet</string>',
                text,
                count=1,
                flags=re.S,
            )
        else:
            text = text.replace('</dict>', '    <key>CFBundleDisplayName</key>\n    <string>Signalet</string>\n</dict>', 1)
        if 'NSPhotoLibraryUsageDescription' not in text:
            text = text.replace('</dict>', '    <key>NSPhotoLibraryUsageDescription</key>\n    <string>Choose a chart screenshot for local on-device analysis.</string>\n</dict>', 1)
        if 'NSCameraUsageDescription' not in text:
            text = text.replace('</dict>', '    <key>NSCameraUsageDescription</key>\n    <string>Take a photo of a chart for local on-device analysis.</string>\n</dict>', 1)
        info.write_text(text)

    runner = ROOT / 'ios/Runner'
    if runner.exists():
        entitlements = runner / 'Runner.entitlements'
        if not entitlements.exists():
            entitlements.write_text('''<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>\n  <key>com.apple.developer.kernel.extended-virtual-addressing</key><true/>\n  <key>com.apple.developer.kernel.increased-memory-limit</key><true/>\n  <key>com.apple.developer.kernel.increased-debugging-memory-limit</key><true/>\n</dict></plist>\n''')
        project = ROOT / 'ios/Runner.xcodeproj/project.pbxproj'
        if project.exists():
            text = project.read_text()
            # The plugin requires iOS 15+ on both the Podfile and Runner target.
            text = re.sub(
                r'IPHONEOS_DEPLOYMENT_TARGET = [^;]+;',
                'IPHONEOS_DEPLOYMENT_TARGET = 15.0;',
                text,
            )
            if 'CODE_SIGN_ENTITLEMENTS = Runner/Runner.entitlements;' not in text:
                def add_runner_entitlement(match):
                    line = match.group(0)
                    # Do not apply the app's large-model entitlements to test runners.
                    if 'RunnerTests' in line or 'UITests' in line:
                        return line
                    return line + '\n\t\t\t\tCODE_SIGN_ENTITLEMENTS = Runner/Runner.entitlements;'
                text = re.sub(r'PRODUCT_BUNDLE_IDENTIFIER = [^;]+;', add_runner_entitlement, text)
            project.write_text(text)

def main():
    configure_android()
    configure_ios()
    print('Configured Android API 30/arm64 and iOS target 15.0/photo-camera descriptions/large-model entitlements where runner files exist.')

if __name__ == '__main__':
    main()
